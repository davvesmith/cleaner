import * as React from "react";
import { Image, StyleSheet, Text, View, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const HomePage = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.homePage}>
      <Image
        style={styles.homePageChild}
        resizeMode="cover"
        source={require("../assets/ellipse-21.png")}
      />
      <Image
        style={styles.homePageItem}
        resizeMode="cover"
        source={require("../assets/line-51.png")}
      />
      <Text style={[styles.search, styles.searchFlexBox]}>Search</Text>
      <Text style={[styles.popularServices, styles.servicesTypo]}>
        Popular Services
      </Text>
      <Text style={[styles.recentlyUsedServices, styles.servicesTypo]}>
        Recently Used Services
      </Text>
      <Image
        style={[styles.homePageInner, styles.containerPosition]}
        resizeMode="cover"
        source={require("../assets/ellipse-22.png")}
      />
      <View style={[styles.rectangleView, styles.homeChildLayout4]} />
      <Pressable
        style={styles.wrapper}
        onPress={() => navigation.navigate("Favorites")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/star-2.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.container, styles.containerPosition]}
        onPress={() => navigation.navigate("ServiceIntro")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/ellipse-2.png")}
        />
      </Pressable>
      <Image
        style={styles.lineIcon}
        resizeMode="cover"
        source={require("../assets/line-5.png")}
      />
      <View style={[styles.lineView, styles.lineViewBorder]} />
      <View style={[styles.homePageChild1, styles.lineViewBorder]} />
      <Image
        style={styles.polygonIcon}
        resizeMode="cover"
        source={require("../assets/polygon-1.png")}
      />
      <Image
        style={styles.ellipseIcon}
        resizeMode="cover"
        source={require("../assets/ellipse-1.png")}
      />
      <Text style={[styles.profile, styles.searchFlexBox]}>Profile</Text>
      <Image
        style={[styles.starIcon, styles.homeChildPosition5]}
        resizeMode="cover"
        source={require("../assets/star-7.png")}
      />
      <Image
        style={[styles.homePageChild2, styles.homeChildPosition5]}
        resizeMode="cover"
        source={require("../assets/star-7.png")}
      />
      <Image
        style={[styles.homePageChild3, styles.homeChildPosition5]}
        resizeMode="cover"
        source={require("../assets/star-9.png")}
      />
      <Image
        style={[styles.homePageChild4, styles.homeChildPosition5]}
        resizeMode="cover"
        source={require("../assets/star-10.png")}
      />
      <Image
        style={[styles.homePageChild5, styles.homeChildPosition4]}
        resizeMode="cover"
        source={require("../assets/star-9.png")}
      />
      <Image
        style={[styles.homePageChild6, styles.homeChildLayout2]}
        resizeMode="cover"
        source={require("../assets/line-8.png")}
      />
      <Pressable
        style={styles.bigClean}
        onPress={() => navigation.navigate("Scheduler1")}
      >
        <Text style={[styles.bigClean1, styles.bigTypo]}>Big Clean</Text>
      </Pressable>
      <Image
        style={styles.baldGuy2}
        resizeMode="cover"
        source={require("../assets/bald-guy-2.png")}
      />
      <Image
        style={[styles.homePageChild7, styles.homeChildLayout2]}
        resizeMode="cover"
        source={require("../assets/line-11.png")}
      />
      <Text style={[styles.thisGuy, styles.westKTypo]}>This Guy</Text>
      <Image
        style={styles.thisGuy2}
        resizeMode="cover"
        source={require("../assets/this-guy-2.png")}
      />
      <Image
        style={[styles.homePageChild8, styles.homeChildLayout1]}
        resizeMode="cover"
        source={require("../assets/star-12.png")}
      />
      <Image
        style={[styles.homePageChild9, styles.homeChildPosition2]}
        resizeMode="cover"
        source={require("../assets/star-12.png")}
      />
      <Image
        style={[styles.homePageChild10, styles.homeChildPosition1]}
        resizeMode="cover"
        source={require("../assets/star-12.png")}
      />
      <Image
        style={[styles.homePageChild11, styles.homeChildLayout]}
        resizeMode="cover"
        source={require("../assets/star-15.png")}
      />
      <Image
        style={[styles.homePageChild12, styles.homeChildLayout1]}
        resizeMode="cover"
        source={require("../assets/star-16.png")}
      />
      <Image
        style={[styles.homePageChild13, styles.homeChildPosition]}
        resizeMode="cover"
        source={require("../assets/star-17.png")}
      />
      <Image
        style={[styles.homePageChild14, styles.homeChildPosition]}
        resizeMode="cover"
        source={require("../assets/star-17.png")}
      />
      <Image
        style={[styles.homePageChild15, styles.homeChildPosition]}
        resizeMode="cover"
        source={require("../assets/star-17.png")}
      />
      <Image
        style={[styles.homePageChild16, styles.homeChildPosition]}
        resizeMode="cover"
        source={require("../assets/star-20.png")}
      />
      <Image
        style={[styles.homePageChild17, styles.homeChildPosition]}
        resizeMode="cover"
        source={require("../assets/star-17.png")}
      />
      <Image
        style={[styles.homePageChild18, styles.homeChildLayout2]}
        resizeMode="cover"
        source={require("../assets/line-12.png")}
      />
      <Image
        style={[styles.homePageChild19, styles.homeChildLayout2]}
        resizeMode="cover"
        source={require("../assets/line-13.png")}
      />
      <Text
        style={[styles.westK, styles.westKTypo]}
      >{`West & K Cleaning`}</Text>
      <Pressable
        style={styles.bigClean2}
        onPress={() => navigation.navigate("Scheduler1")}
      >
        <Text style={[styles.bigClean3, styles.bigTypo]}>Big Clean</Text>
      </Pressable>
      <Image
        style={[styles.baldGuy21, styles.baldGuy21Position]}
        resizeMode="cover"
        source={require("../assets/bald-guy-3.png")}
      />
      <Image
        style={[styles.cleaningService1, styles.baldGuy21Position]}
        resizeMode="cover"
        source={require("../assets/cleaning-service-2.png")}
      />
      <Pressable
        style={[styles.rectanglePressable, styles.homeChildLayout1]}
        onPress={() => navigation.navigate("ServiceIntro")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  searchFlexBox: {
    textAlign: "center",
    color: Color.black,
    position: "absolute",
  },
  servicesTypo: {
    fontFamily: FontFamily.h3,
    fontWeight: "700",
    lineHeight: 30,
    letterSpacing: -0.5,
    textAlign: "center",
    color: Color.black,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  containerPosition: {
    left: 117,
    position: "absolute",
  },
  homeChildLayout4: {
    width: 390,
    left: 0,
  },
  lineViewBorder: {
    borderColor: "#000",
    borderStyle: "solid",
    position: "absolute",
  },
  homeChildPosition5: {
    height: 43,
    top: 662,
    position: "absolute",
  },
  homeChildPosition4: {
    left: 299,
    width: 43,
  },
  homeChildLayout2: {
    height: 2,
    position: "absolute",
  },
  bigTypo: {
    fontFamily: FontFamily.firaSansRegular,
    textAlign: "center",
    color: Color.black,
    fontSize: FontSize.h3_size,
  },
  westKTypo: {
    left: 115,
    fontFamily: FontFamily.firaSansRegular,
    textAlign: "center",
    color: Color.black,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  homeChildLayout1: {
    height: 46,
    position: "absolute",
  },
  homeChildPosition2: {
    left: 165,
    width: 43,
  },
  homeChildPosition1: {
    left: 210,
    width: 43,
  },
  homeChildLayout: {
    width: 44,
    left: 253,
  },
  homeChildPosition: {
    height: 47,
    top: 516,
    position: "absolute",
  },
  baldGuy21Position: {
    left: 12,
    position: "absolute",
  },
  homePageChild: {
    top: 221,
    left: 125,
    width: 19,
    height: 17,
    opacity: 0.5,
    position: "absolute",
  },
  homePageItem: {
    top: 235,
    left: 141,
    width: 10,
    height: 8,
    opacity: 0.5,
    position: "absolute",
  },
  search: {
    top: 219,
    left: 118,
    fontFamily: FontFamily.karmaRegular,
    width: 156,
    height: 33,
    fontSize: FontSize.h3_size,
    textAlign: "center",
    color: Color.black,
    opacity: 0.5,
  },
  popularServices: {
    top: 308,
    left: 39,
    width: 223,
    height: 31,
  },
  recentlyUsedServices: {
    top: 576,
    left: 32,
    width: 286,
    height: 21,
  },
  homePageInner: {
    top: 26,
    width: 158,
    height: 153,
  },
  rectangleView: {
    backgroundColor: Color.darkslateblue,
    height: 85,
    top: 759,
    width: 390,
    position: "absolute",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  wrapper: {
    left: 207,
    top: 773,
    width: 74,
    height: 58,
    position: "absolute",
  },
  container: {
    top: 788,
    height: 27,
    width: 30,
  },
  lineIcon: {
    top: 811,
    left: 143,
    width: 15,
    height: 13,
    position: "absolute",
  },
  lineView: {
    borderTopWidth: 1,
    width: 391,
    height: 1,
    left: 0,
    borderColor: "#000",
    borderStyle: "solid",
    top: 759,
  },
  homePageChild1: {
    top: 798,
    left: 25,
    backgroundColor: Color.white,
    borderWidth: 2,
    height: 26,
    width: 30,
  },
  polygonIcon: {
    top: 780,
    left: 18,
    width: 53,
    height: 29,
    position: "absolute",
  },
  ellipseIcon: {
    top: 774,
    left: 315,
    width: 59,
    height: 56,
    position: "absolute",
  },
  profile: {
    top: 791,
    left: 304,
    fontSize: FontSize.size_base,
    fontWeight: "600",
    fontFamily: FontFamily.karmaSemiBold,
    height: 22,
    width: 81,
  },
  starIcon: {
    left: 119,
    width: 42,
    height: 43,
    top: 662,
  },
  homePageChild2: {
    left: 167,
    width: 42,
    height: 43,
    top: 662,
  },
  homePageChild3: {
    left: 212,
    width: 43,
    height: 43,
    top: 662,
  },
  homePageChild4: {
    left: 255,
    width: 41,
    height: 43,
    top: 662,
  },
  homePageChild5: {
    height: 43,
    top: 662,
    position: "absolute",
  },
  homePageChild6: {
    top: 615,
    width: 390,
    left: 0,
  },
  bigClean1: {
    width: 116,
    height: 38,
  },
  bigClean: {
    left: 110,
    top: 629,
    position: "absolute",
  },
  baldGuy2: {
    top: 632,
    left: 6,
    width: 90,
    height: 59,
    position: "absolute",
  },
  homePageChild7: {
    top: 709,
    width: 390,
    left: 0,
  },
  thisGuy: {
    top: 718,
  },
  thisGuy2: {
    top: 715,
    left: 9,
    width: 87,
    height: 44,
    position: "absolute",
  },
  homePageChild8: {
    left: 116,
    top: 411,
    height: 46,
    width: 43,
  },
  homePageChild9: {
    height: 46,
    position: "absolute",
    top: 411,
  },
  homePageChild10: {
    height: 46,
    position: "absolute",
    top: 411,
  },
  homePageChild11: {
    height: 46,
    position: "absolute",
    top: 411,
  },
  homePageChild12: {
    top: 411,
    height: 46,
    left: 299,
    width: 43,
  },
  homePageChild13: {
    left: 116,
    width: 43,
  },
  homePageChild14: {
    left: 165,
    width: 43,
  },
  homePageChild15: {
    left: 210,
    width: 43,
  },
  homePageChild16: {
    width: 44,
    left: 253,
  },
  homePageChild17: {
    left: 299,
    width: 43,
  },
  homePageChild18: {
    top: 357,
    left: 1,
    width: 384,
  },
  homePageChild19: {
    top: 469,
    width: 390,
    left: 0,
  },
  westK: {
    top: 372,
    width: 197,
    height: 23,
  },
  bigClean3: {
    width: 101,
    height: 22,
  },
  bigClean2: {
    top: 480,
    left: 116,
    position: "absolute",
  },
  baldGuy21: {
    width: 86,
    height: 72,
    top: 480,
  },
  cleaningService1: {
    top: 373,
    height: 75,
    width: 81,
  },
  rectanglePressable: {
    top: 212,
    left: 78,
    borderRadius: Border.br_3xs,
    backgroundColor: Color.gainsboro,
    width: 236,
    opacity: 0.5,
  },
  homePage: {
    backgroundColor: Color.lavenderblush,
    flex: 1,
    height: 844,
    overflow: "hidden",
    width: "100%",
  },
});

export default HomePage;
