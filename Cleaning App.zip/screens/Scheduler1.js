import * as React from "react";
import { Text, StyleSheet, View, Pressable, Image } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const Scheduler1 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.scheduler}>
      <Text style={[styles.setDate, styles.text35Clr]}>Set Date</Text>
      <View style={styles.schedulerChild} />
      <Text style={[styles.m, styles.mPosition]}>M</Text>
      <Text style={[styles.t, styles.textTypo5]}>T</Text>
      <Text style={[styles.w, styles.mPosition]}>W</Text>
      <Text style={[styles.t1, styles.textTypo4]}>T</Text>
      <Text style={[styles.f, styles.textTypo3]}>F</Text>
      <Text style={[styles.s, styles.textTypo2]}>S</Text>
      <Text style={[styles.s1, styles.textTypo1]}>S</Text>
      <Pressable
        style={[styles.pressable, styles.textPosition8]}
        onPress={() => navigation.navigate("Overlay")}
      >
        <Text style={[styles.text, styles.textLayout]}>1</Text>
      </Pressable>
      <Text style={[styles.text1, styles.textLayout]}>2</Text>
      <Text style={[styles.text2, styles.textLayout]}>3</Text>
      <Text style={[styles.text3, styles.textLayout]}>4</Text>
      <Text style={[styles.text4, styles.textLayout]}>5</Text>
      <Text style={[styles.text5, styles.textLayout]}>6</Text>
      <Text style={[styles.text6, styles.textLayout]}>7</Text>
      <Text style={[styles.text7, styles.textPosition7]}>8</Text>
      <Text style={[styles.text8, styles.textPosition7]}>9</Text>
      <Pressable
        style={[styles.pressable1, styles.textPosition7]}
        onPress={() => navigation.navigate("Overlay")}
      >
        <Text style={[styles.text9, styles.textLayout]}>10</Text>
      </Pressable>
      <Text style={[styles.text10, styles.textPosition7]}>11</Text>
      <Text style={[styles.text11, styles.textPosition7]}>12</Text>
      <Text style={[styles.text12, styles.textPosition7]}>13</Text>
      <Text style={[styles.text13, styles.textPosition7]}>14</Text>
      <Text style={[styles.text14, styles.textPosition5]}>15</Text>
      <Text style={[styles.text15, styles.textPosition4]}>16</Text>
      <Text style={[styles.text16, styles.textPosition6]}>17</Text>
      <Text style={[styles.text17, styles.textPosition3]}>18</Text>
      <Pressable
        style={[styles.pressable2, styles.textPosition6]}
        onPress={() => navigation.navigate("Overlay")}
      >
        <Text style={[styles.text18, styles.textLayout]}>19</Text>
      </Pressable>
      <Text style={[styles.text19, styles.textPosition2]}>20</Text>
      <Text style={[styles.text20, styles.textPosition1]}>21</Text>
      <Text style={[styles.text21, styles.textPosition]}>22</Text>
      <Text style={[styles.text22, styles.textPosition]}>23</Text>
      <Pressable
        style={[styles.pressable3, styles.textPosition]}
        onPress={() => navigation.navigate("Overlay")}
      >
        <Text style={[styles.text23, styles.textLayout]}>24</Text>
      </Pressable>
      <Text style={[styles.text24, styles.textPosition]}>25</Text>
      <Text style={[styles.text25, styles.textPosition]}>26</Text>
      <Text style={[styles.text26, styles.textPosition]}>27</Text>
      <Text style={[styles.text27, styles.textPosition]}>28</Text>
      <Text style={[styles.text28, styles.textTypo]}>29</Text>
      <Text style={[styles.text29, styles.textTypo]}>30</Text>
      <Text style={[styles.text30, styles.textTypo]}>31</Text>
      <Text style={[styles.text31, styles.textTypo]}>1</Text>
      <Text style={[styles.text32, styles.textTypo]}>2</Text>
      <Text style={[styles.text33, styles.textTypo]}>3</Text>
      <Text style={[styles.text34, styles.textTypo]}>4</Text>
      <View style={[styles.schedulerItem, styles.schedulerItemLayout]} />
      <Text style={[styles.am, styles.amTypo]}>10:00am</Text>
      <Text style={[styles.powerWasher, styles.back1Typo]}>Power Washer</Text>
      <View style={[styles.schedulerInner, styles.lineViewLayout]} />
      <Text style={[styles.insertNoteHere, styles.insertTypo]}>
        (Insert Note Here)
      </Text>
      <Text style={[styles.am11am, styles.pm1pmLayout]}>10am-11am</Text>
      <View style={[styles.rectangleView, styles.schedulerItemLayout]} />
      <Text style={[styles.pm, styles.amTypo]}>12:00pm</Text>
      <Text style={[styles.windowCleaner, styles.pm1pmTypo]}>
        Window Cleaner
      </Text>
      <View style={[styles.lineView, styles.lineViewLayout]} />
      <Text style={[styles.insertNoteHere1, styles.insertTypo]}>
        (Insert Note Here)
      </Text>
      <Text style={[styles.pm1pm, styles.pm1pmTypo]}>12pm-1pm</Text>
      <Text style={[styles.text35, styles.text35Clr]}>+</Text>
      <View style={styles.schedulerChild1} />
      <Pressable
        style={[styles.rectanglePressable, styles.ellipseIconLayout]}
        onPress={() => navigation.navigate("HomePage")}
      />
      <View style={[styles.schedulerChild2, styles.schedulerChildLayout]} />
      <Pressable
        style={styles.wrapper}
        onPress={() => navigation.navigate("Favorites")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/star-1.png")}
        />
      </Pressable>
      <View style={[styles.schedulerChild3, styles.schedulerChildLayout]} />
      <Image
        style={styles.lineIcon}
        resizeMode="cover"
        source={require("../assets/line-5.png")}
      />
      <Image
        style={[styles.ellipseIcon, styles.ellipseIconLayout]}
        resizeMode="cover"
        source={require("../assets/ellipse-2.png")}
      />
      <View style={[styles.schedulerChild4, styles.schedulerChildLayout]} />
      <Image
        style={styles.polygonIcon}
        resizeMode="cover"
        source={require("../assets/polygon-1.png")}
      />
      <Image
        style={styles.schedulerChild5}
        resizeMode="cover"
        source={require("../assets/ellipse-1.png")}
      />
      <Text style={[styles.profile, styles.am11amTypo]}>Profile</Text>
      <Pressable
        style={styles.back}
        onPress={() => navigation.navigate("ComapniesLists")}
      >
        <Text style={[styles.back1, styles.back1Typo]}>Back</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  text35Clr: {
    color: Color.black,
    textAlign: "center",
  },
  mPosition: {
    height: 66,
    top: 167,
    opacity: 0.35,
    color: Color.black,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  textTypo5: {
    left: 79,
    width: 33,
    letterSpacing: 24,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  textTypo4: {
    width: 35,
    left: 176,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  textTypo3: {
    left: 226,
    width: 33,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  textTypo2: {
    left: 275,
    width: 33,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  textTypo1: {
    left: 324,
    width: 33,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  textPosition8: {
    top: 233,
    position: "absolute",
  },
  textLayout: {
    height: 32,
    color: Color.black,
    fontSize: FontSize.h3_size,
  },
  textPosition7: {
    top: 300,
    position: "absolute",
  },
  textPosition5: {
    left: 31,
    width: 33,
  },
  textPosition4: {
    left: 80,
    width: 33,
  },
  textPosition6: {
    top: 367,
    position: "absolute",
  },
  textPosition3: {
    left: 177,
    width: 35,
  },
  textPosition2: {
    left: 276,
    width: 33,
  },
  textPosition1: {
    left: 325,
    width: 33,
  },
  textPosition: {
    top: 434,
    position: "absolute",
  },
  textTypo: {
    top: 501,
    height: 32,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.karmaRegular,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  schedulerItemLayout: {
    width: 367,
    borderRadius: Border.br_xl,
    left: 6,
    height: 66,
    position: "absolute",
  },
  amTypo: {
    width: 95,
    left: 23,
    height: 27,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    textAlign: "center",
    color: Color.black,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  back1Typo: {
    height: 28,
    textAlign: "center",
    color: Color.black,
    fontSize: FontSize.h3_size,
  },
  lineViewLayout: {
    height: 1,
    width: 368,
    borderTopWidth: 1,
    borderColor: "#000",
    borderStyle: "solid",
    left: 6,
    position: "absolute",
  },
  insertTypo: {
    height: 21,
    width: 169,
    color: Color.white,
    fontSize: FontSize.size_xl,
    left: 19,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    textAlign: "center",
    position: "absolute",
  },
  pm1pmLayout: {
    height: 14,
    width: 106,
    left: 257,
    color: Color.white,
    fontSize: FontSize.size_xl,
  },
  pm1pmTypo: {
    top: 733,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    textAlign: "center",
    position: "absolute",
  },
  ellipseIconLayout: {
    width: 30,
    position: "absolute",
  },
  schedulerChildLayout: {
    height: 86,
    width: 1,
    borderRightWidth: 1,
    top: 759,
    borderColor: "#000",
    borderStyle: "solid",
    position: "absolute",
  },
  am11amTypo: {
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    position: "absolute",
  },
  setDate: {
    width: 161,
    height: 35,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
    fontSize: FontSize.h3_size,
    color: Color.black,
    left: 117,
    top: 89,
    position: "absolute",
  },
  schedulerChild: {
    top: 741,
    left: 86,
    backgroundColor: Color.gainsboro,
    width: 100,
    height: 100,
    position: "absolute",
  },
  m: {
    opacity: 0.35,
    width: 33,
    letterSpacing: 24,
    left: 30,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  t: {
    opacity: 0.35,
    height: 66,
    top: 167,
    color: Color.black,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  w: {
    width: 34,
    left: 127,
    opacity: 0.35,
    letterSpacing: 24,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  t1: {
    opacity: 0.35,
    height: 66,
    top: 167,
    color: Color.black,
    fontSize: FontSize.h3_size,
    position: "absolute",
    letterSpacing: 24,
  },
  f: {
    opacity: 0.35,
    height: 66,
    top: 167,
    color: Color.black,
    fontSize: FontSize.h3_size,
    position: "absolute",
    letterSpacing: 24,
  },
  s: {
    opacity: 0.35,
    height: 66,
    top: 167,
    color: Color.black,
    fontSize: FontSize.h3_size,
    position: "absolute",
    letterSpacing: 24,
  },
  s1: {
    opacity: 0.35,
    height: 66,
    top: 167,
    color: Color.black,
    fontSize: FontSize.h3_size,
    position: "absolute",
    letterSpacing: 24,
  },
  text: {
    width: 33,
    letterSpacing: 24,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  pressable: {
    left: 30,
  },
  text1: {
    top: 233,
    position: "absolute",
    left: 79,
    width: 33,
    letterSpacing: 24,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  text2: {
    top: 233,
    position: "absolute",
    width: 34,
    left: 127,
    letterSpacing: 24,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  text3: {
    top: 233,
    position: "absolute",
    width: 35,
    left: 176,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
    letterSpacing: 24,
  },
  text4: {
    top: 233,
    position: "absolute",
    left: 226,
    width: 33,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
    letterSpacing: 24,
  },
  text5: {
    top: 233,
    position: "absolute",
    left: 275,
    width: 33,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
    letterSpacing: 24,
  },
  text6: {
    top: 233,
    position: "absolute",
    left: 324,
    width: 33,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
    letterSpacing: 24,
  },
  text7: {
    height: 32,
    color: Color.black,
    fontSize: FontSize.h3_size,
    width: 33,
    letterSpacing: 24,
    left: 30,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  text8: {
    height: 32,
    color: Color.black,
    fontSize: FontSize.h3_size,
    left: 79,
    width: 33,
    letterSpacing: 24,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  text9: {
    width: 43,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  pressable1: {
    left: 127,
  },
  text10: {
    height: 32,
    color: Color.black,
    fontSize: FontSize.h3_size,
    width: 35,
    left: 176,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  text11: {
    height: 32,
    color: Color.black,
    fontSize: FontSize.h3_size,
    left: 226,
    width: 33,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  text12: {
    height: 32,
    color: Color.black,
    fontSize: FontSize.h3_size,
    left: 275,
    width: 33,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  text13: {
    height: 32,
    color: Color.black,
    fontSize: FontSize.h3_size,
    left: 324,
    width: 33,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  text14: {
    top: 367,
    position: "absolute",
    height: 32,
    color: Color.black,
    fontSize: FontSize.h3_size,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  text15: {
    top: 367,
    position: "absolute",
    height: 32,
    color: Color.black,
    fontSize: FontSize.h3_size,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  text16: {
    left: 128,
    height: 32,
    color: Color.black,
    fontSize: FontSize.h3_size,
    width: 34,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  text17: {
    top: 367,
    position: "absolute",
    height: 32,
    color: Color.black,
    fontSize: FontSize.h3_size,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  text18: {
    width: 33,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  pressable2: {
    left: 227,
  },
  text19: {
    top: 367,
    position: "absolute",
    height: 32,
    color: Color.black,
    fontSize: FontSize.h3_size,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  text20: {
    top: 367,
    position: "absolute",
    height: 32,
    color: Color.black,
    fontSize: FontSize.h3_size,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  text21: {
    left: 31,
    width: 33,
    height: 32,
    color: Color.black,
    fontSize: FontSize.h3_size,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  text22: {
    left: 80,
    width: 33,
    height: 32,
    color: Color.black,
    fontSize: FontSize.h3_size,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  text23: {
    width: 34,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  pressable3: {
    left: 128,
  },
  text24: {
    left: 177,
    width: 35,
    height: 32,
    color: Color.black,
    fontSize: FontSize.h3_size,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  text25: {
    left: 227,
    height: 32,
    color: Color.black,
    fontSize: FontSize.h3_size,
    width: 33,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  text26: {
    left: 276,
    width: 33,
    height: 32,
    color: Color.black,
    fontSize: FontSize.h3_size,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  text27: {
    left: 325,
    width: 33,
    height: 32,
    color: Color.black,
    fontSize: FontSize.h3_size,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  text28: {
    left: 31,
    width: 33,
  },
  text29: {
    left: 80,
    width: 33,
  },
  text30: {
    left: 128,
    width: 34,
  },
  text31: {
    left: 177,
    width: 35,
    opacity: 0.35,
  },
  text32: {
    left: 227,
    opacity: 0.35,
    width: 33,
  },
  text33: {
    left: 276,
    width: 33,
    opacity: 0.35,
  },
  text34: {
    left: 325,
    width: 33,
    opacity: 0.35,
  },
  schedulerItem: {
    backgroundColor: Color.mediumpurple,
    top: 614,
  },
  am: {
    top: 575,
    height: 27,
  },
  powerWasher: {
    left: 15,
    width: 183,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    position: "absolute",
    top: 614,
  },
  schedulerInner: {
    top: 647,
  },
  insertNoteHere: {
    top: 652,
  },
  am11am: {
    top: 618,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    position: "absolute",
    textAlign: "center",
  },
  rectangleView: {
    top: 729,
    backgroundColor: Color.palevioletred,
  },
  pm: {
    top: 690,
    height: 27,
  },
  windowCleaner: {
    left: 7,
    width: 224,
    height: 32,
    color: Color.black,
    fontSize: FontSize.h3_size,
  },
  lineView: {
    top: 762,
  },
  insertNoteHere1: {
    top: 767,
  },
  pm1pm: {
    height: 14,
    width: 106,
    left: 257,
    color: Color.white,
    fontSize: FontSize.size_xl,
  },
  text35: {
    top: 74,
    left: 326,
    fontSize: FontSize.size_21xl,
    width: 37,
    height: 50,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
    position: "absolute",
  },
  schedulerChild1: {
    left: 0,
    backgroundColor: Color.darkslateblue,
    width: 390,
    height: 85,
    top: 759,
    position: "absolute",
  },
  rectanglePressable: {
    top: 795,
    left: 25,
    backgroundColor: Color.white,
    borderWidth: 2,
    height: 26,
    borderColor: "#000",
    borderStyle: "solid",
    width: 30,
  },
  schedulerChild2: {
    left: 83,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  wrapper: {
    left: 207,
    top: 773,
    width: 63,
    height: 57,
    position: "absolute",
  },
  schedulerChild3: {
    left: 294,
  },
  lineIcon: {
    top: 809,
    left: 143,
    width: 15,
    height: 13,
    position: "absolute",
  },
  ellipseIcon: {
    top: 788,
    height: 27,
    width: 30,
    left: 117,
  },
  schedulerChild4: {
    left: 189,
  },
  polygonIcon: {
    top: 780,
    left: 18,
    width: 53,
    height: 29,
    position: "absolute",
  },
  schedulerChild5: {
    top: 774,
    left: 315,
    width: 59,
    height: 56,
    position: "absolute",
  },
  profile: {
    top: 793,
    left: 303,
    fontSize: FontSize.size_base,
    width: 81,
    height: 22,
    textAlign: "center",
    color: Color.black,
  },
  back1: {
    width: 98,
    fontFamily: FontFamily.karmaRegular,
  },
  back: {
    left: -6,
    top: 89,
    position: "absolute",
  },
  scheduler: {
    backgroundColor: Color.lavenderblush,
    flex: 1,
    height: 844,
    overflow: "hidden",
    width: "100%",
  },
});

export default Scheduler1;
