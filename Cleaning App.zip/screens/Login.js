import * as React from "react";
import { Image, StyleSheet, View, Pressable, Text } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const Login = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.login}>
      <Image
        style={styles.loginChild}
        resizeMode="cover"
        source={require("../assets/ellipse-11.png")}
      />
      <View style={[styles.loginItem, styles.loginLayout]} />
      <View style={[styles.loginInner, styles.loginLayout]} />
      <Pressable
        style={styles.rectanglePressable}
        onPress={() => navigation.navigate("HomePage")}
      />
      <Text style={[styles.username, styles.usernameTypo]}>username</Text>
      <Text style={[styles.password, styles.usernameTypo]}>password</Text>
      <Text style={styles.welcomeBack}>Welcome back!</Text>
      <Text style={styles.login1}>Login</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  loginLayout: {
    height: 45,
    backgroundColor: Color.plum,
    width: 309,
    borderWidth: 2,
    borderColor: "#000",
    borderStyle: "solid",
    borderRadius: Border.br_3xs,
    left: 35,
    position: "absolute",
  },
  usernameTypo: {
    opacity: 0.5,
    height: 33,
    width: 285,
    textAlign: "center",
    color: Color.white,
    fontFamily: FontFamily.karmaRegular,
    fontSize: FontSize.h3_size,
    left: 47,
    position: "absolute",
  },
  loginChild: {
    top: 88,
    left: 37,
    width: 317,
    height: 316,
    position: "absolute",
  },
  loginItem: {
    top: 478,
  },
  loginInner: {
    top: 542,
  },
  rectanglePressable: {
    top: 614,
    backgroundColor: "#3774cf",
    height: 77,
    width: 309,
    borderWidth: 2,
    borderColor: "#000",
    borderStyle: "solid",
    borderRadius: Border.br_3xs,
    left: 35,
    position: "absolute",
  },
  username: {
    top: 484,
  },
  password: {
    top: 548,
  },
  welcomeBack: {
    top: 431,
    color: Color.black,
    height: 30,
    width: 285,
    left: 47,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  login1: {
    top: 637,
    left: 42,
    width: 290,
    height: 32,
    textAlign: "center",
    color: Color.white,
    fontFamily: FontFamily.karmaRegular,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  login: {
    backgroundColor: Color.lavenderblush,
    flex: 1,
    width: "100%",
    height: 844,
    overflow: "hidden",
  },
});

export default Login;
