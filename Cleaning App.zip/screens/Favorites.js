import * as React from "react";
import { Text, StyleSheet, View, Pressable, Image } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const Favorites = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.favorites}>
      <Text
        style={[styles.welcomeToYour, styles.westKFlexBox]}
      >{`Welcome to your favorites page!

These are the companies you have marked as your favorites!

`}</Text>
      <Text style={[styles.favorites1, styles.westKFlexBox]}>Favorites</Text>
      <View style={[styles.favoritesChild, styles.favoritesChildLayout6]} />
      <Pressable
        style={[styles.favoritesItem, styles.wrapperLayout]}
        onPress={() => navigation.navigate("HomePage")}
      />
      <Image
        style={[styles.favoritesInner, styles.favoritesChildLayout6]}
        resizeMode="cover"
        source={require("../assets/rectangle-1.png")}
      />
      <View style={[styles.lineView, styles.favoritesChildLayout5]} />
      <Image
        style={styles.starIcon}
        resizeMode="cover"
        source={require("../assets/star-1.png")}
      />
      <Image
        style={[styles.favoritesChild1, styles.favoritesChildLayout4]}
        resizeMode="cover"
        source={require("../assets/star-22.png")}
      />
      <Image
        style={[styles.favoritesChild2, styles.favoritesChildLayout4]}
        resizeMode="cover"
        source={require("../assets/star-22.png")}
      />
      <Image
        style={[styles.favoritesChild3, styles.favoritesChildLayout4]}
        resizeMode="cover"
        source={require("../assets/star-22.png")}
      />
      <Image
        style={[styles.favoritesChild4, styles.favoritesChildLayout4]}
        resizeMode="cover"
        source={require("../assets/star-22.png")}
      />
      <Image
        style={[styles.favoritesChild5, styles.favoritesChildLayout4]}
        resizeMode="cover"
        source={require("../assets/star-26.png")}
      />
      <Image
        style={[styles.favoritesChild6, styles.favoritesChildPosition5]}
        resizeMode="cover"
        source={require("../assets/star-22.png")}
      />
      <Image
        style={[styles.favoritesChild7, styles.favoritesChildPosition5]}
        resizeMode="cover"
        source={require("../assets/star-26.png")}
      />
      <Image
        style={[styles.favoritesChild8, styles.favoritesChildPosition5]}
        resizeMode="cover"
        source={require("../assets/star-26.png")}
      />
      <Image
        style={[styles.favoritesChild9, styles.favoritesChildPosition5]}
        resizeMode="cover"
        source={require("../assets/star-26.png")}
      />
      <Image
        style={[styles.favoritesChild10, styles.favoritesChildPosition5]}
        resizeMode="cover"
        source={require("../assets/star-26.png")}
      />
      <View style={[styles.favoritesChild11, styles.favoritesChildLayout5]} />
      <Image
        style={styles.lineIcon}
        resizeMode="cover"
        source={require("../assets/line-5.png")}
      />
      <Pressable
        style={[styles.wrapper, styles.wrapperLayout]}
        onPress={() => navigation.navigate("ServiceIntro")}
      >
        <Image
          style={styles.iconLayout}
          resizeMode="cover"
          source={require("../assets/ellipse-2.png")}
        />
      </Pressable>
      <View style={[styles.favoritesChild12, styles.favoritesChildLayout5]} />
      <View style={[styles.favoritesChild13, styles.favoritesChildLayout3]} />
      <Pressable
        style={styles.container}
        onPress={() => navigation.navigate("HomePage")}
      >
        <Image
          style={styles.iconLayout}
          resizeMode="cover"
          source={require("../assets/polygon-1.png")}
        />
      </Pressable>
      <Image
        style={styles.ellipseIcon}
        resizeMode="cover"
        source={require("../assets/ellipse-1.png")}
      />
      <Image
        style={[styles.favoritesChild14, styles.favoritesChildLayout2]}
        resizeMode="cover"
        source={require("../assets/line-9.png")}
      />
      <View style={[styles.favoritesChild15, styles.favoritesChildLayout3]} />
      <Text style={[styles.betterCleaning, styles.cleanTypo]}>
        Better Cleaning
      </Text>
      <Text style={[styles.thisGuy, styles.cleanTypo]}>This Guy</Text>
      <Text style={[styles.whoaThatsClean, styles.cleanTypo]}>
        Whoa That’s Clean
      </Text>
      <Image
        style={styles.cleaning21}
        resizeMode="cover"
        source={require("../assets/cleaning-2-1.png")}
      />
      <Image
        style={styles.thisGuy1}
        resizeMode="cover"
        source={require("../assets/this-guy-1.png")}
      />
      <Text style={[styles.profile, styles.profileLayout]}>Profile</Text>
      <Image
        style={styles.clean1Icon}
        resizeMode="cover"
        source={require("../assets/clean-1.png")}
      />
      <Image
        style={[styles.favoritesChild16, styles.favoritesChildPosition4]}
        resizeMode="cover"
        source={require("../assets/star-12.png")}
      />
      <Image
        style={[styles.favoritesChild17, styles.favoritesChildPosition3]}
        resizeMode="cover"
        source={require("../assets/star-12.png")}
      />
      <Image
        style={[styles.favoritesChild18, styles.favoritesChildPosition2]}
        resizeMode="cover"
        source={require("../assets/star-12.png")}
      />
      <Image
        style={[styles.favoritesChild19, styles.favoritesChildLayout]}
        resizeMode="cover"
        source={require("../assets/star-15.png")}
      />
      <Image
        style={[styles.favoritesChild20, styles.favoritesChildPosition1]}
        resizeMode="cover"
        source={require("../assets/star-16.png")}
      />
      <Image
        style={[styles.favoritesChild21, styles.favoritesChildPosition]}
        resizeMode="cover"
        source={require("../assets/star-17.png")}
      />
      <Image
        style={[styles.favoritesChild22, styles.favoritesChildPosition]}
        resizeMode="cover"
        source={require("../assets/star-17.png")}
      />
      <Image
        style={[styles.favoritesChild23, styles.favoritesChildPosition]}
        resizeMode="cover"
        source={require("../assets/star-17.png")}
      />
      <Image
        style={[styles.favoritesChild24, styles.favoritesChildPosition]}
        resizeMode="cover"
        source={require("../assets/star-20.png")}
      />
      <Image
        style={[styles.favoritesChild25, styles.favoritesChildPosition]}
        resizeMode="cover"
        source={require("../assets/star-17.png")}
      />
      <Image
        style={[styles.favoritesChild26, styles.favoritesChildLayout2]}
        resizeMode="cover"
        source={require("../assets/line-12.png")}
      />
      <Image
        style={[styles.favoritesChild27, styles.favoritesChildLayout2]}
        resizeMode="cover"
        source={require("../assets/line-13.png")}
      />
      <Text
        style={[styles.westK, styles.cleanTypo]}
      >{`West & K Cleaning`}</Text>
      <Pressable
        style={styles.bigClean}
        onPress={() => navigation.navigate("Scheduler1")}
      >
        <Text style={[styles.bigClean1, styles.profileLayout]}>Big Clean</Text>
      </Pressable>
      <Image
        style={[styles.baldGuy3, styles.baldGuy3Position]}
        resizeMode="cover"
        source={require("../assets/bald-guy-3.png")}
      />
      <Image
        style={[styles.cleaningService2, styles.baldGuy3Position]}
        resizeMode="cover"
        source={require("../assets/cleaning-service-2.png")}
      />
      <Image
        style={[styles.favoritesChild28, styles.favoritesChildLayout2]}
        resizeMode="cover"
        source={require("../assets/line-19.png")}
      />
      <Pressable
        style={styles.back}
        onPress={() => navigation.navigate("HomePage")}
      >
        <Text style={styles.back1}>Back</Text>
      </Pressable>
      <Pressable
        style={styles.frame}
        onPress={() => navigation.navigate("ServiceIntro")}
      >
        <Image
          style={[styles.icon2, styles.iconLayout]}
          resizeMode="cover"
          source={require("../assets/rectangle-17.png")}
        />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  westKFlexBox: {
    textAlign: "center",
    color: Color.black,
    position: "absolute",
  },
  favoritesChildLayout6: {
    width: 390,
    left: 0,
  },
  wrapperLayout: {
    width: 30,
    position: "absolute",
  },
  favoritesChildLayout5: {
    height: 86,
    width: 1,
    borderRightWidth: 1,
    borderColor: "#000",
    borderStyle: "solid",
    top: 759,
    position: "absolute",
  },
  favoritesChildLayout4: {
    height: 34,
    width: 38,
    top: 535,
    position: "absolute",
  },
  favoritesChildPosition5: {
    top: 643,
    height: 34,
    width: 38,
    position: "absolute",
  },
  favoritesChildLayout3: {
    height: 1,
    width: 391,
    borderTopWidth: 1,
    borderColor: "#000",
    borderStyle: "solid",
    position: "absolute",
  },
  favoritesChildLayout2: {
    height: 2,
    position: "absolute",
  },
  cleanTypo: {
    fontFamily: FontFamily.firaSansRegular,
    fontSize: FontSize.h3_size,
  },
  profileLayout: {
    height: 22,
    textAlign: "center",
    color: Color.black,
  },
  favoritesChildPosition4: {
    height: 46,
    top: 320,
    position: "absolute",
  },
  favoritesChildPosition3: {
    left: 172,
    width: 43,
  },
  favoritesChildPosition2: {
    left: 217,
    width: 43,
  },
  favoritesChildLayout: {
    width: 44,
    left: 260,
  },
  favoritesChildPosition1: {
    left: 306,
    width: 43,
  },
  favoritesChildPosition: {
    height: 47,
    top: 425,
    position: "absolute",
  },
  baldGuy3Position: {
    left: 19,
    position: "absolute",
  },
  iconLayout: {
    height: "100%",
    width: "100%",
  },
  welcomeToYour: {
    top: 133,
    left: 68,
    width: 256,
    height: 101,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_base,
  },
  favorites1: {
    top: 18,
    left: 30,
    fontSize: FontSize.size_29xl,
    width: 328,
    height: 60,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
  },
  favoritesChild: {
    backgroundColor: Color.darkslateblue,
    height: 85,
    top: 759,
    position: "absolute",
  },
  favoritesItem: {
    top: 795,
    left: 25,
    backgroundColor: Color.white,
    borderWidth: 2,
    height: 26,
    borderColor: "#000",
    borderStyle: "solid",
    width: 30,
  },
  favoritesInner: {
    top: 0,
    height: 107,
    opacity: 0.2,
    position: "absolute",
  },
  lineView: {
    left: 83,
  },
  starIcon: {
    top: 773,
    left: 207,
    width: 63,
    height: 57,
    position: "absolute",
  },
  favoritesChild1: {
    left: 115,
  },
  favoritesChild2: {
    left: 158,
  },
  favoritesChild3: {
    left: 198,
  },
  favoritesChild4: {
    left: 236,
  },
  favoritesChild5: {
    left: 276,
  },
  favoritesChild6: {
    left: 115,
  },
  favoritesChild7: {
    left: 158,
  },
  favoritesChild8: {
    left: 198,
  },
  favoritesChild9: {
    left: 236,
  },
  favoritesChild10: {
    left: 276,
  },
  favoritesChild11: {
    left: 294,
  },
  lineIcon: {
    top: 809,
    left: 143,
    width: 15,
    height: 13,
    position: "absolute",
  },
  wrapper: {
    left: 117,
    top: 788,
    height: 27,
  },
  favoritesChild12: {
    left: 189,
  },
  favoritesChild13: {
    left: 0,
    top: 759,
  },
  container: {
    left: 18,
    top: 780,
    width: 53,
    height: 29,
    position: "absolute",
  },
  ellipseIcon: {
    top: 774,
    left: 315,
    width: 59,
    height: 56,
    position: "absolute",
  },
  favoritesChild14: {
    top: 586,
    width: 384,
    left: 0,
  },
  favoritesChild15: {
    top: 688,
    left: -6,
  },
  betterCleaning: {
    top: 499,
    left: 115,
    textAlign: "center",
    color: Color.black,
    position: "absolute",
  },
  thisGuy: {
    top: 607,
    left: 115,
    textAlign: "center",
    color: Color.black,
    position: "absolute",
  },
  whoaThatsClean: {
    top: 730,
    left: 115,
    textAlign: "center",
    color: Color.black,
    position: "absolute",
  },
  cleaning21: {
    top: 490,
    left: 15,
    width: 84,
    height: 79,
    position: "absolute",
  },
  thisGuy1: {
    top: 600,
    left: 14,
    width: 85,
    height: 77,
    position: "absolute",
  },
  profile: {
    top: 793,
    left: 303,
    width: 81,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  clean1Icon: {
    top: 721,
    left: 11,
    width: 88,
    height: 38,
    position: "absolute",
  },
  favoritesChild16: {
    width: 43,
    left: 123,
  },
  favoritesChild17: {
    height: 46,
    top: 320,
    position: "absolute",
  },
  favoritesChild18: {
    height: 46,
    top: 320,
    position: "absolute",
  },
  favoritesChild19: {
    height: 46,
    top: 320,
    position: "absolute",
  },
  favoritesChild20: {
    height: 46,
    top: 320,
    position: "absolute",
  },
  favoritesChild21: {
    width: 43,
    left: 123,
  },
  favoritesChild22: {
    left: 172,
    width: 43,
  },
  favoritesChild23: {
    left: 217,
    width: 43,
  },
  favoritesChild24: {
    width: 44,
    left: 260,
  },
  favoritesChild25: {
    left: 306,
    width: 43,
  },
  favoritesChild26: {
    top: 266,
    left: 8,
    width: 382,
  },
  favoritesChild27: {
    top: 378,
    width: 390,
    left: 0,
  },
  westK: {
    top: 281,
    left: 122,
    width: 197,
    height: 23,
    textAlign: "center",
    color: Color.black,
    position: "absolute",
  },
  bigClean1: {
    width: 101,
    fontFamily: FontFamily.firaSansRegular,
    fontSize: FontSize.h3_size,
  },
  bigClean: {
    top: 389,
    left: 123,
    position: "absolute",
  },
  baldGuy3: {
    width: 86,
    height: 72,
    top: 389,
  },
  cleaningService2: {
    top: 282,
    height: 75,
    width: 81,
  },
  favoritesChild28: {
    top: 479,
    width: 390,
    left: 0,
  },
  back1: {
    fontFamily: FontFamily.karmaRegular,
    width: 98,
    height: 28,
    fontSize: FontSize.h3_size,
    textAlign: "center",
    color: Color.black,
  },
  back: {
    left: -13,
    top: 134,
    position: "absolute",
  },
  icon2: {
    borderRadius: Border.br_3xs,
  },
  frame: {
    left: -430,
    top: 218,
    width: 271,
    height: 39,
    position: "absolute",
  },
  favorites: {
    backgroundColor: Color.lavenderblush,
    flex: 1,
    height: 844,
    overflow: "hidden",
    width: "100%",
  },
});

export default Favorites;
