import * as React from "react";
import { StyleSheet, View, Pressable, Text, Image } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const ResidentialServices = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.residentialServices}>
      <Pressable
        style={styles.residentialServicesChild}
        onPress={() => navigation.navigate("ComapniesLists")}
      />
      <Pressable
        style={[styles.residentialServicesItem, styles.residentialChildLayout1]}
        onPress={() => navigation.navigate("ComapniesLists")}
      />
      <View
        style={[
          styles.residentialServicesInner,
          styles.residentialChildLayout1,
        ]}
      />
      <Pressable
        style={[styles.rectanglePressable, styles.residentialChildLayout1]}
        onPress={() => navigation.navigate("ComapniesLists")}
      />
      <Pressable
        style={[
          styles.residentialServicesChild1,
          styles.residentialChildLayout1,
        ]}
        onPress={() => navigation.navigate("ComapniesLists")}
      />
      <Text
        style={[styles.welcomeToOur, styles.profileTypo]}
      >{`Welcome to our services page!
We offer all the necessary services to meet your cleaning needs. 
Both commercials and residential.`}</Text>
      <View style={[styles.rectangleView, styles.rectanglePosition]} />
      <Pressable
        style={[styles.residentialServicesChild2, styles.containerLayout]}
        onPress={() => navigation.navigate("HomePage")}
      />
      <Image
        style={styles.lineIcon}
        resizeMode="cover"
        source={require("../assets/line-5.png")}
      />
      <View style={[styles.lineView, styles.residentialChildLayout]} />
      <Pressable
        style={styles.wrapper}
        onPress={() => navigation.navigate("Favorites")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/star-2.png")}
        />
      </Pressable>
      <View
        style={[
          styles.residentialServicesChild3,
          styles.residentialChildLayout,
        ]}
      />
      <Pressable
        style={[styles.container, styles.containerLayout]}
        onPress={() => navigation.navigate("ServiceIntro")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/ellipse-2.png")}
        />
      </Pressable>
      <View
        style={[
          styles.residentialServicesChild4,
          styles.residentialChildLayout,
        ]}
      />
      <View style={styles.residentialServicesChild5} />
      <Pressable
        style={styles.frame}
        onPress={() => navigation.navigate("HomePage")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/polygon-1.png")}
        />
      </Pressable>
      <Image
        style={styles.ellipseIcon}
        resizeMode="cover"
        source={require("../assets/ellipse-1.png")}
      />
      <Text style={[styles.moveInoutCleaning, styles.cleaningTypo]}>
        Move In/Out Cleaning
      </Text>
      <Pressable
        style={[styles.customClean, styles.customCleanPosition]}
        onPress={() => navigation.navigate("ComapniesLists")}
      >
        <Text style={styles.cleaningTypo}>Custom Clean</Text>
      </Pressable>
      <Text style={[styles.generalCleaning, styles.customCleanPosition]}>
        General Cleaning
      </Text>
      <Text style={[styles.deepCleaning, styles.cleaningTypo]}>
        Deep Cleaning
      </Text>
      <Pressable
        style={[
          styles.residentialServicesChild6,
          styles.residentialChildLayout1,
        ]}
        onPress={() => navigation.navigate("ComapniesLists")}
      />
      <Text style={[styles.recurringMaintenance, styles.cleaningTypo]}>
        Recurring Maintenance
      </Text>
      <Text style={[styles.inHomeLaundry, styles.customCleanPosition]}>
        In-Home Laundry
      </Text>
      <Text style={[styles.profile, styles.profileTypo]}>Profile</Text>
      <Image
        style={[styles.rectangleIcon, styles.rectanglePosition]}
        resizeMode="cover"
        source={require("../assets/rectangle-11.png")}
      />
      <Text style={[styles.residential, styles.profileTypo]}>Residential</Text>
      <Pressable
        style={styles.back}
        onPress={() => navigation.navigate("ServiceIntro")}
      >
        <Text style={styles.back1}>Back</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  residentialChildLayout1: {
    left: 35,
    height: 62,
    width: 321,
    borderWidth: 3,
    borderColor: "#000",
    borderStyle: "solid",
    backgroundColor: Color.plum,
    borderRadius: Border.br_3xs,
    position: "absolute",
  },
  profileTypo: {
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    position: "absolute",
  },
  rectanglePosition: {
    width: 390,
    left: 0,
    position: "absolute",
  },
  containerLayout: {
    width: 30,
    position: "absolute",
  },
  residentialChildLayout: {
    height: 86,
    width: 1,
    borderRightWidth: 1,
    top: 759,
    borderColor: "#000",
    borderStyle: "solid",
    position: "absolute",
  },
  cleaningTypo: {
    height: 36,
    width: 302,
    color: Color.white,
    fontSize: FontSize.h3_size,
    textAlign: "center",
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
  },
  customCleanPosition: {
    left: 45,
    position: "absolute",
  },
  residentialServicesChild: {
    top: 279,
    left: 34,
    height: 62,
    width: 321,
    borderWidth: 3,
    backgroundColor: Color.plum,
    borderRadius: Border.br_3xs,
    borderColor: "#000",
    borderStyle: "solid",
    position: "absolute",
  },
  residentialServicesItem: {
    top: 362,
  },
  residentialServicesInner: {
    top: 444,
  },
  rectanglePressable: {
    top: 526,
  },
  residentialServicesChild1: {
    top: 608,
  },
  welcomeToOur: {
    top: 147,
    left: 67,
    width: 256,
    height: 101,
    fontSize: FontSize.size_base,
    color: Color.black,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
  },
  rectangleView: {
    backgroundColor: Color.darkslateblue,
    height: 85,
    top: 759,
    width: 390,
  },
  residentialServicesChild2: {
    top: 795,
    left: 25,
    backgroundColor: Color.white,
    borderWidth: 2,
    height: 26,
    borderColor: "#000",
    borderStyle: "solid",
    width: 30,
  },
  lineIcon: {
    top: 809,
    left: 143,
    width: 15,
    height: 13,
    position: "absolute",
  },
  lineView: {
    left: 83,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  wrapper: {
    left: 207,
    top: 773,
    width: 74,
    height: 58,
    position: "absolute",
  },
  residentialServicesChild3: {
    left: 294,
  },
  container: {
    left: 117,
    top: 788,
    height: 27,
  },
  residentialServicesChild4: {
    left: 189,
  },
  residentialServicesChild5: {
    borderTopWidth: 1,
    width: 391,
    height: 1,
    left: 0,
    top: 759,
    borderColor: "#000",
    borderStyle: "solid",
    position: "absolute",
  },
  frame: {
    left: 18,
    top: 780,
    width: 53,
    height: 29,
    position: "absolute",
  },
  ellipseIcon: {
    top: 774,
    left: 315,
    width: 59,
    height: 56,
    position: "absolute",
  },
  moveInoutCleaning: {
    top: 294,
    left: 43,
    width: 302,
    color: Color.white,
    position: "absolute",
  },
  customClean: {
    top: 458,
  },
  generalCleaning: {
    top: 543,
    height: 36,
    width: 302,
    color: Color.white,
    fontSize: FontSize.h3_size,
    textAlign: "center",
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
  },
  deepCleaning: {
    top: 622,
    left: 43,
    width: 302,
    color: Color.white,
    position: "absolute",
  },
  residentialServicesChild6: {
    top: 690,
  },
  recurringMaintenance: {
    top: 704,
    left: 43,
    width: 302,
    color: Color.white,
    position: "absolute",
  },
  inHomeLaundry: {
    top: 378,
    height: 36,
    width: 302,
    color: Color.white,
    fontSize: FontSize.h3_size,
    textAlign: "center",
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
  },
  profile: {
    top: 791,
    left: 304,
    width: 81,
    height: 22,
    fontSize: FontSize.size_base,
    color: Color.black,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
  },
  rectangleIcon: {
    top: 0,
    height: 103,
    opacity: 0.2,
  },
  residential: {
    top: 22,
    left: 33,
    fontSize: FontSize.size_29xl,
    width: 326,
    height: 59,
  },
  back1: {
    fontFamily: FontFamily.karmaRegular,
    width: 98,
    height: 28,
    fontSize: FontSize.h3_size,
    textAlign: "center",
    color: Color.black,
  },
  back: {
    left: -4,
    top: 124,
    position: "absolute",
  },
  residentialServices: {
    backgroundColor: Color.lavenderblush,
    flex: 1,
    height: 844,
    overflow: "hidden",
    width: "100%",
  },
});

export default ResidentialServices;
