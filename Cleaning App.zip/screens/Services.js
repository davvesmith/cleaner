import * as React from "react";
import { StyleSheet, View, Pressable, Text, Image } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const Services = () => {
  const navigation = useNavigation();

  return (
    <Pressable
      style={styles.services}
      onPress={() => navigation.navigate("ServiceIntro")}
    >
      <Pressable
        style={[styles.servicesChild, styles.servicesChildLayout1]}
        onPress={() => navigation.navigate("ComapniesLists")}
      />
      <Pressable
        style={[styles.servicesItem, styles.servicesBorder]}
        onPress={() => navigation.navigate("ComapniesLists")}
      />
      <View style={[styles.servicesInner, styles.servicesBorder]} />
      <Text
        style={[styles.welcomeToOur, styles.profileTypo]}
      >{`Welcome to our services page!
We offer all the necessary services to meet your cleaning needs. 
Both commercials and residential.`}</Text>
      <Text style={[styles.services1, styles.profileTypo]}>Services</Text>
      <View style={[styles.rectangleView, styles.rectanglePosition]} />
      <Image
        style={styles.lineIcon}
        resizeMode="cover"
        source={require("../assets/line-5.png")}
      />
      <Image
        style={[styles.rectangleIcon, styles.rectanglePosition]}
        resizeMode="cover"
        source={require("../assets/rectangle-11.png")}
      />
      <View style={[styles.lineView, styles.servicesChildLayout]} />
      <Pressable
        style={styles.wrapper}
        onPress={() => navigation.navigate("Favorites")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/star-2.png")}
        />
      </Pressable>
      <View style={[styles.servicesChild1, styles.servicesChildLayout]} />
      <Pressable
        style={[styles.container, styles.containerLayout]}
        onPress={() => navigation.navigate("ServiceIntro")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/ellipse-2.png")}
        />
      </Pressable>
      <View style={[styles.servicesChild2, styles.servicesChildLayout]} />
      <View style={styles.servicesChild3} />
      <Image
        style={styles.ellipseIcon}
        resizeMode="cover"
        source={require("../assets/ellipse-1.png")}
      />
      <Text style={[styles.carDealership, styles.handWash1Typo]}>
        Car Dealership
      </Text>
      <Pressable
        style={[styles.rectanglePressable, styles.servicesChildLayout1]}
        onPress={() => navigation.navigate("ComapniesLists")}
      />
      <Text style={[styles.government, styles.handWash1Typo]}>Government</Text>
      <Pressable
        style={[styles.handWash, styles.handWashPosition]}
        onPress={() => navigation.navigate("ComapniesLists")}
      >
        <Text style={styles.handWash1Typo}>Hand Wash</Text>
      </Pressable>
      <Text style={styles.commercial}>Commercial</Text>
      <Text style={[styles.profile, styles.profileTypo]}>Profile</Text>
      <Pressable
        style={[styles.servicesChild4, styles.containerLayout]}
        onPress={() => navigation.navigate("HomePage")}
      />
      <Image
        style={styles.polygonIcon}
        resizeMode="cover"
        source={require("../assets/polygon-1.png")}
      />
      <Pressable
        style={styles.back}
        onPress={() => navigation.navigate("ServiceIntro")}
      >
        <Text style={styles.back1}>Back</Text>
      </Pressable>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  servicesChildLayout1: {
    width: 310,
    borderWidth: 3,
    backgroundColor: Color.plum,
    borderRadius: Border.br_3xs,
    left: 40,
    height: 82,
    borderColor: "#000",
    borderStyle: "solid",
    position: "absolute",
  },
  servicesBorder: {
    left: 41,
    width: 310,
    borderWidth: 3,
    borderColor: "#000",
    borderStyle: "solid",
    backgroundColor: Color.plum,
    borderRadius: Border.br_3xs,
    position: "absolute",
  },
  profileTypo: {
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    position: "absolute",
  },
  rectanglePosition: {
    width: 390,
    left: 0,
    position: "absolute",
  },
  servicesChildLayout: {
    height: 86,
    width: 1,
    borderRightWidth: 1,
    top: 759,
    borderColor: "#000",
    borderStyle: "solid",
    position: "absolute",
  },
  containerLayout: {
    width: 30,
    position: "absolute",
  },
  handWash1Typo: {
    height: 48,
    width: 291,
    color: Color.white,
    fontSize: FontSize.h3_size,
    textAlign: "center",
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
  },
  handWashPosition: {
    left: 51,
    position: "absolute",
  },
  servicesChild: {
    top: 408,
    height: 82,
  },
  servicesItem: {
    top: 518,
    height: 83,
  },
  servicesInner: {
    top: 627,
    height: 82,
  },
  welcomeToOur: {
    top: 147,
    left: 67,
    width: 256,
    height: 101,
    fontSize: FontSize.size_base,
    color: Color.black,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
  },
  services1: {
    top: 18,
    left: 34,
    fontSize: FontSize.size_29xl,
    width: 325,
    height: 63,
  },
  rectangleView: {
    backgroundColor: Color.darkslateblue,
    height: 85,
    top: 759,
    width: 390,
  },
  lineIcon: {
    top: 809,
    left: 143,
    width: 15,
    height: 13,
    position: "absolute",
  },
  rectangleIcon: {
    top: 0,
    height: 103,
    opacity: 0.2,
  },
  lineView: {
    left: 83,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  wrapper: {
    left: 207,
    top: 773,
    width: 74,
    height: 58,
    position: "absolute",
  },
  servicesChild1: {
    left: 294,
  },
  container: {
    left: 117,
    top: 788,
    height: 27,
  },
  servicesChild2: {
    left: 189,
  },
  servicesChild3: {
    borderTopWidth: 1,
    width: 391,
    height: 1,
    left: 0,
    top: 759,
    borderColor: "#000",
    borderStyle: "solid",
    position: "absolute",
  },
  ellipseIcon: {
    top: 774,
    left: 315,
    width: 59,
    height: 56,
    position: "absolute",
  },
  carDealership: {
    top: 438,
    left: 51,
    position: "absolute",
  },
  rectanglePressable: {
    top: 298,
    height: 82,
  },
  government: {
    top: 328,
    left: 51,
    position: "absolute",
  },
  handWash: {
    top: 656,
  },
  commercial: {
    top: 547,
    height: 47,
    width: 291,
    color: Color.white,
    fontSize: FontSize.h3_size,
    left: 51,
    textAlign: "center",
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    position: "absolute",
  },
  profile: {
    top: 791,
    left: 304,
    width: 81,
    height: 22,
    fontSize: FontSize.size_base,
    color: Color.black,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
  },
  servicesChild4: {
    top: 795,
    left: 28,
    backgroundColor: Color.white,
    borderWidth: 2,
    height: 26,
    borderColor: "#000",
    borderStyle: "solid",
    width: 30,
  },
  polygonIcon: {
    top: 780,
    left: 21,
    width: 53,
    height: 29,
    position: "absolute",
  },
  back1: {
    fontFamily: FontFamily.karmaRegular,
    width: 98,
    height: 28,
    fontSize: FontSize.h3_size,
    textAlign: "center",
    color: Color.black,
  },
  back: {
    left: -6,
    top: 130,
    position: "absolute",
  },
  services: {
    backgroundColor: Color.lavenderblush,
    flex: 1,
    height: 844,
    overflow: "hidden",
    width: "100%",
  },
});

export default Services;
