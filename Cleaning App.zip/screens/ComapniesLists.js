import * as React from "react";
import { Text, StyleSheet, View, Pressable, Image } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, FontSize } from "../GlobalStyles";

const ComapniesLists = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.comapniesLists}>
      <Text
        style={[styles.welcomeToOur, styles.westKFlexBox]}
      >{`Welcome to our companies page!

These are the companies that offer the services you’re looking for!

`}</Text>
      <Text style={[styles.companies, styles.westKFlexBox]}>Companies</Text>
      <View
        style={[styles.comapniesListsChild, styles.comapniesChildLayout6]}
      />
      <Pressable
        style={[styles.comapniesListsItem, styles.containerLayout]}
        onPress={() => navigation.navigate("HomePage")}
      />
      <Image
        style={[styles.comapniesListsInner, styles.comapniesChildLayout6]}
        resizeMode="cover"
        source={require("../assets/rectangle-11.png")}
      />
      <View style={[styles.lineView, styles.comapniesChildLayout5]} />
      <Pressable
        style={styles.wrapper}
        onPress={() => navigation.navigate("Favorites")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/star-1.png")}
        />
      </Pressable>
      <Image
        style={[styles.starIcon, styles.comapniesChildLayout4]}
        resizeMode="cover"
        source={require("../assets/star-22.png")}
      />
      <Image
        style={[styles.comapniesListsChild1, styles.comapniesChildLayout4]}
        resizeMode="cover"
        source={require("../assets/star-22.png")}
      />
      <Image
        style={[styles.comapniesListsChild2, styles.comapniesChildLayout4]}
        resizeMode="cover"
        source={require("../assets/star-22.png")}
      />
      <Image
        style={[styles.comapniesListsChild3, styles.comapniesChildLayout4]}
        resizeMode="cover"
        source={require("../assets/star-22.png")}
      />
      <Image
        style={[styles.comapniesListsChild4, styles.comapniesChildLayout4]}
        resizeMode="cover"
        source={require("../assets/star-26.png")}
      />
      <Image
        style={[styles.comapniesListsChild5, styles.comapniesChildPosition5]}
        resizeMode="cover"
        source={require("../assets/star-22.png")}
      />
      <Image
        style={[styles.comapniesListsChild6, styles.comapniesChildPosition5]}
        resizeMode="cover"
        source={require("../assets/star-26.png")}
      />
      <Image
        style={[styles.comapniesListsChild7, styles.comapniesChildPosition5]}
        resizeMode="cover"
        source={require("../assets/star-26.png")}
      />
      <Image
        style={[styles.comapniesListsChild8, styles.comapniesChildPosition5]}
        resizeMode="cover"
        source={require("../assets/star-26.png")}
      />
      <Image
        style={[styles.comapniesListsChild9, styles.comapniesChildPosition5]}
        resizeMode="cover"
        source={require("../assets/star-26.png")}
      />
      <View
        style={[styles.comapniesListsChild10, styles.comapniesChildLayout5]}
      />
      <Image
        style={styles.lineIcon}
        resizeMode="cover"
        source={require("../assets/line-5.png")}
      />
      <Pressable
        style={[styles.container, styles.containerLayout]}
        onPress={() => navigation.navigate("ServiceIntro")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/ellipse-2.png")}
        />
      </Pressable>
      <View
        style={[styles.comapniesListsChild11, styles.comapniesChildLayout5]}
      />
      <View
        style={[styles.comapniesListsChild12, styles.comapniesChildLayout3]}
      />
      <Pressable
        style={styles.frame}
        onPress={() => navigation.navigate("HomePage")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/polygon-1.png")}
        />
      </Pressable>
      <Image
        style={styles.ellipseIcon}
        resizeMode="cover"
        source={require("../assets/ellipse-1.png")}
      />
      <Image
        style={[styles.comapniesListsChild13, styles.comapniesChildLayout2]}
        resizeMode="cover"
        source={require("../assets/line-9.png")}
      />
      <View
        style={[styles.comapniesListsChild14, styles.comapniesChildLayout3]}
      />
      <Text style={[styles.betterCleaning, styles.cleanTypo]}>
        Better Cleaning
      </Text>
      <Text style={[styles.thisGuy, styles.cleanTypo]}>This Guy</Text>
      <Text style={[styles.whoaThatsClean, styles.cleanTypo]}>
        Whoa That’s Clean
      </Text>
      <Image
        style={styles.cleaning21}
        resizeMode="cover"
        source={require("../assets/cleaning-2-1.png")}
      />
      <Image
        style={styles.thisGuy1}
        resizeMode="cover"
        source={require("../assets/this-guy-1.png")}
      />
      <Text style={[styles.profile, styles.profileLayout]}>Profile</Text>
      <Image
        style={styles.clean1Icon}
        resizeMode="cover"
        source={require("../assets/clean-1.png")}
      />
      <Image
        style={[styles.comapniesListsChild15, styles.comapniesChildPosition4]}
        resizeMode="cover"
        source={require("../assets/star-12.png")}
      />
      <Image
        style={[styles.comapniesListsChild16, styles.comapniesChildPosition3]}
        resizeMode="cover"
        source={require("../assets/star-12.png")}
      />
      <Image
        style={[styles.comapniesListsChild17, styles.comapniesChildPosition2]}
        resizeMode="cover"
        source={require("../assets/star-12.png")}
      />
      <Image
        style={[styles.comapniesListsChild18, styles.comapniesChildLayout]}
        resizeMode="cover"
        source={require("../assets/star-15.png")}
      />
      <Image
        style={[styles.comapniesListsChild19, styles.comapniesChildPosition1]}
        resizeMode="cover"
        source={require("../assets/star-16.png")}
      />
      <Image
        style={[styles.comapniesListsChild20, styles.comapniesChildPosition]}
        resizeMode="cover"
        source={require("../assets/star-17.png")}
      />
      <Image
        style={[styles.comapniesListsChild21, styles.comapniesChildPosition]}
        resizeMode="cover"
        source={require("../assets/star-17.png")}
      />
      <Image
        style={[styles.comapniesListsChild22, styles.comapniesChildPosition]}
        resizeMode="cover"
        source={require("../assets/star-17.png")}
      />
      <Image
        style={[styles.comapniesListsChild23, styles.comapniesChildPosition]}
        resizeMode="cover"
        source={require("../assets/star-20.png")}
      />
      <Image
        style={[styles.comapniesListsChild24, styles.comapniesChildPosition]}
        resizeMode="cover"
        source={require("../assets/star-17.png")}
      />
      <Image
        style={[styles.comapniesListsChild25, styles.comapniesChildLayout2]}
        resizeMode="cover"
        source={require("../assets/line-12.png")}
      />
      <Image
        style={[styles.comapniesListsChild26, styles.comapniesChildLayout2]}
        resizeMode="cover"
        source={require("../assets/line-13.png")}
      />
      <Text
        style={[styles.westK, styles.cleanTypo]}
      >{`West & K Cleaning`}</Text>
      <Pressable
        style={styles.bigClean}
        onPress={() => navigation.navigate("Scheduler1")}
      >
        <Text style={[styles.bigClean1, styles.profileLayout]}>Big Clean</Text>
      </Pressable>
      <Image
        style={[styles.baldGuy3, styles.baldGuy3Position]}
        resizeMode="cover"
        source={require("../assets/bald-guy-3.png")}
      />
      <Image
        style={[styles.cleaningService2, styles.baldGuy3Position]}
        resizeMode="cover"
        source={require("../assets/cleaning-service-2.png")}
      />
      <Image
        style={[styles.comapniesListsChild27, styles.comapniesChildLayout2]}
        resizeMode="cover"
        source={require("../assets/line-19.png")}
      />
      <Pressable
        style={styles.back}
        onPress={() => navigation.navigate("CarServices")}
      >
        <Text style={styles.back1}>Back</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  westKFlexBox: {
    textAlign: "center",
    color: Color.black,
    position: "absolute",
  },
  comapniesChildLayout6: {
    width: 390,
    left: 0,
  },
  containerLayout: {
    width: 30,
    position: "absolute",
  },
  comapniesChildLayout5: {
    height: 86,
    width: 1,
    borderRightWidth: 1,
    borderColor: "#000",
    borderStyle: "solid",
    top: 759,
    position: "absolute",
  },
  comapniesChildLayout4: {
    height: 34,
    width: 38,
    top: 535,
    position: "absolute",
  },
  comapniesChildPosition5: {
    top: 643,
    height: 34,
    width: 38,
    position: "absolute",
  },
  comapniesChildLayout3: {
    height: 1,
    width: 391,
    borderTopWidth: 1,
    borderColor: "#000",
    borderStyle: "solid",
    position: "absolute",
  },
  comapniesChildLayout2: {
    height: 2,
    position: "absolute",
  },
  cleanTypo: {
    fontFamily: FontFamily.firaSansRegular,
    fontSize: FontSize.h3_size,
  },
  profileLayout: {
    height: 22,
    textAlign: "center",
    color: Color.black,
  },
  comapniesChildPosition4: {
    height: 46,
    top: 320,
    position: "absolute",
  },
  comapniesChildPosition3: {
    left: 172,
    width: 43,
  },
  comapniesChildPosition2: {
    left: 217,
    width: 43,
  },
  comapniesChildLayout: {
    width: 44,
    left: 260,
  },
  comapniesChildPosition1: {
    left: 306,
    width: 43,
  },
  comapniesChildPosition: {
    height: 47,
    top: 425,
    position: "absolute",
  },
  baldGuy3Position: {
    left: 19,
    position: "absolute",
  },
  welcomeToOur: {
    top: 133,
    left: 68,
    width: 256,
    height: 101,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_base,
  },
  companies: {
    top: 18,
    left: 30,
    fontSize: FontSize.size_29xl,
    width: 329,
    height: 39,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
  },
  comapniesListsChild: {
    backgroundColor: Color.darkslateblue,
    height: 85,
    top: 759,
    position: "absolute",
  },
  comapniesListsItem: {
    top: 795,
    left: 25,
    backgroundColor: Color.white,
    borderWidth: 2,
    height: 26,
    borderColor: "#000",
    borderStyle: "solid",
    width: 30,
  },
  comapniesListsInner: {
    top: 0,
    height: 103,
    opacity: 0.2,
    position: "absolute",
  },
  lineView: {
    left: 83,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  wrapper: {
    left: 207,
    top: 773,
    width: 63,
    height: 57,
    position: "absolute",
  },
  starIcon: {
    left: 115,
  },
  comapniesListsChild1: {
    left: 158,
  },
  comapniesListsChild2: {
    left: 198,
  },
  comapniesListsChild3: {
    left: 236,
  },
  comapniesListsChild4: {
    left: 276,
  },
  comapniesListsChild5: {
    left: 115,
  },
  comapniesListsChild6: {
    left: 158,
  },
  comapniesListsChild7: {
    left: 198,
  },
  comapniesListsChild8: {
    left: 236,
  },
  comapniesListsChild9: {
    left: 276,
  },
  comapniesListsChild10: {
    left: 294,
  },
  lineIcon: {
    top: 809,
    left: 143,
    width: 15,
    height: 13,
    position: "absolute",
  },
  container: {
    left: 117,
    top: 788,
    height: 27,
  },
  comapniesListsChild11: {
    left: 189,
  },
  comapniesListsChild12: {
    left: 0,
    top: 759,
  },
  frame: {
    left: 18,
    top: 780,
    width: 53,
    height: 29,
    position: "absolute",
  },
  ellipseIcon: {
    top: 774,
    left: 315,
    width: 59,
    height: 56,
    position: "absolute",
  },
  comapniesListsChild13: {
    top: 586,
    width: 384,
    left: 0,
  },
  comapniesListsChild14: {
    top: 688,
    left: -6,
  },
  betterCleaning: {
    top: 499,
    left: 115,
    textAlign: "center",
    color: Color.black,
    position: "absolute",
  },
  thisGuy: {
    top: 607,
    left: 115,
    textAlign: "center",
    color: Color.black,
    position: "absolute",
  },
  whoaThatsClean: {
    top: 730,
    left: 115,
    textAlign: "center",
    color: Color.black,
    position: "absolute",
  },
  cleaning21: {
    top: 490,
    left: 15,
    width: 84,
    height: 79,
    position: "absolute",
  },
  thisGuy1: {
    top: 600,
    left: 14,
    width: 85,
    height: 77,
    position: "absolute",
  },
  profile: {
    top: 793,
    left: 303,
    width: 81,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  clean1Icon: {
    top: 721,
    left: 11,
    width: 88,
    height: 38,
    position: "absolute",
  },
  comapniesListsChild15: {
    width: 43,
    left: 123,
  },
  comapniesListsChild16: {
    height: 46,
    top: 320,
    position: "absolute",
  },
  comapniesListsChild17: {
    height: 46,
    top: 320,
    position: "absolute",
  },
  comapniesListsChild18: {
    height: 46,
    top: 320,
    position: "absolute",
  },
  comapniesListsChild19: {
    height: 46,
    top: 320,
    position: "absolute",
  },
  comapniesListsChild20: {
    width: 43,
    left: 123,
  },
  comapniesListsChild21: {
    left: 172,
    width: 43,
  },
  comapniesListsChild22: {
    left: 217,
    width: 43,
  },
  comapniesListsChild23: {
    width: 44,
    left: 260,
  },
  comapniesListsChild24: {
    left: 306,
    width: 43,
  },
  comapniesListsChild25: {
    top: 266,
    left: 8,
    width: 382,
  },
  comapniesListsChild26: {
    top: 378,
    width: 390,
    left: 0,
  },
  westK: {
    top: 281,
    left: 122,
    width: 197,
    height: 23,
    textAlign: "center",
    color: Color.black,
    position: "absolute",
  },
  bigClean1: {
    width: 101,
    fontFamily: FontFamily.firaSansRegular,
    fontSize: FontSize.h3_size,
  },
  bigClean: {
    top: 389,
    left: 123,
    position: "absolute",
  },
  baldGuy3: {
    width: 86,
    height: 72,
    top: 389,
  },
  cleaningService2: {
    top: 282,
    height: 75,
    width: 81,
  },
  comapniesListsChild27: {
    top: 479,
    width: 390,
    left: 0,
  },
  back1: {
    fontFamily: FontFamily.karmaRegular,
    width: 98,
    height: 28,
    fontSize: FontSize.h3_size,
    textAlign: "center",
    color: Color.black,
  },
  back: {
    left: -13,
    top: 134,
    position: "absolute",
  },
  comapniesLists: {
    backgroundColor: Color.lavenderblush,
    flex: 1,
    height: 844,
    overflow: "hidden",
    width: "100%",
  },
});

export default ComapniesLists;
