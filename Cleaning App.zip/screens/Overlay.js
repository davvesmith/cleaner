import * as React from "react";
import { Text, StyleSheet, View, Image, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const Overlay = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.overlay}>
      <Text style={styles.setADate}>Set a date</Text>
      <Text style={[styles.m, styles.mTypo]}>M</Text>
      <Text style={[styles.t, styles.mTypo]}>T</Text>
      <Text style={[styles.w, styles.wLayout]}>W</Text>
      <Text style={[styles.t1, styles.textLayout1]}>T</Text>
      <Text style={[styles.f, styles.textPosition10]}>F</Text>
      <Text style={[styles.s, styles.textPosition9]}>S</Text>
      <Text style={[styles.s1, styles.textPosition8]}>S</Text>
      <Text style={[styles.text, styles.textLayout]}>1</Text>
      <Text style={[styles.text1, styles.textLayout]}>2</Text>
      <Text style={[styles.text2, styles.textLayout]}>3</Text>
      <Text style={[styles.text3, styles.textLayout]}>4</Text>
      <Text style={[styles.text4, styles.textLayout]}>5</Text>
      <Text style={[styles.text5, styles.textLayout]}>6</Text>
      <Text style={[styles.text6, styles.textLayout]}>7</Text>
      <Text style={[styles.text7, styles.textTypo3]}>8</Text>
      <Text style={[styles.text8, styles.textTypo3]}>9</Text>
      <Text style={[styles.text9, styles.textTypo3]}>10</Text>
      <Text style={[styles.text10, styles.textTypo3]}>11</Text>
      <Text style={[styles.text11, styles.textTypo3]}>12</Text>
      <Text style={[styles.text12, styles.textTypo3]}>13</Text>
      <Text style={[styles.text13, styles.textTypo3]}>14</Text>
      <Text style={[styles.text14, styles.textPosition6]}>15</Text>
      <Text style={[styles.text15, styles.textPosition5]}>16</Text>
      <Text style={[styles.text16, styles.textPosition4]}>17</Text>
      <Text style={[styles.text17, styles.textPosition3]}>18</Text>
      <Text style={[styles.text18, styles.textPosition2]}>19</Text>
      <Text style={[styles.text19, styles.textPosition1]}>20</Text>
      <Text style={[styles.text20, styles.textPosition]}>21</Text>
      <Text style={[styles.text21, styles.textTypo1]}>22</Text>
      <Text style={[styles.text22, styles.textTypo1]}>23</Text>
      <Text style={[styles.text23, styles.textTypo1]}>24</Text>
      <Text style={[styles.text24, styles.textTypo1]}>25</Text>
      <Text style={[styles.text25, styles.textTypo1]}>26</Text>
      <Text style={[styles.text26, styles.textTypo1]}>27</Text>
      <Text style={[styles.text27, styles.textTypo1]}>28</Text>
      <Text style={[styles.text28, styles.textTypo]}>29</Text>
      <Text style={[styles.text29, styles.textTypo]}>30</Text>
      <Text style={[styles.text30, styles.textTypo]}>31</Text>
      <Text style={[styles.text31, styles.textTypo]}>1</Text>
      <Text style={[styles.text32, styles.textTypo]}>2</Text>
      <Text style={[styles.text33, styles.textTypo]}>3</Text>
      <Text style={[styles.text34, styles.textTypo]}>4</Text>
      <View style={[styles.overlayChild, styles.overlayLayout]} />
      <Text style={[styles.am, styles.amTypo]}>10:00am</Text>
      <Text style={[styles.powerWasher, styles.newEventTypo]}>
        Power Washer
      </Text>
      <View style={[styles.overlayItem, styles.lineViewLayout]} />
      <Text style={[styles.insertNoteHere, styles.insertTypo]}>
        (Insert Note Here)
      </Text>
      <Text style={[styles.am11am, styles.pm1pmLayout]}>10am-11am</Text>
      <View style={[styles.overlayInner, styles.overlayLayout]} />
      <Text style={[styles.pm, styles.amTypo]}>12:00pm</Text>
      <Text style={[styles.windowCleaner, styles.pm1pmTypo]}>
        Window Cleaner
      </Text>
      <View style={[styles.lineView, styles.lineViewLayout]} />
      <Text style={[styles.insertNoteHere1, styles.insertTypo]}>
        (Insert Note Here)
      </Text>
      <Text style={[styles.pm1pm, styles.pm1pmTypo]}>12pm-1pm</Text>
      <Image
        style={styles.overlayIcon}
        resizeMode="cover"
        source={require("../assets/overlay.png")}
      />
      <Image
        style={[styles.overlayIcon1, styles.overlayIconPosition]}
        resizeMode="cover"
        source={require("../assets/overlay1.png")}
      />
      <Image
        style={[styles.overlayIcon2, styles.overlayIconPosition]}
        resizeMode="cover"
        source={require("../assets/overlay2.png")}
      />
      <Text style={[styles.newEvent, styles.newEventTypo]}>New Event</Text>
      <Text style={[styles.date, styles.dateTypo]}>Date:</Text>
      <Image
        style={[styles.lineIcon, styles.overlayChildLayout]}
        resizeMode="cover"
        source={require("../assets/line-15.png")}
      />
      <Text style={[styles.title, styles.dateTypo]}>Title:</Text>
      <Image
        style={[styles.overlayChild1, styles.overlayChildLayout]}
        resizeMode="cover"
        source={require("../assets/line-16.png")}
      />
      <Text style={[styles.instructions, styles.textLayout]}>Instructions</Text>
      <Image
        style={[styles.overlayChild2, styles.overlayChildLayout]}
        resizeMode="cover"
        source={require("../assets/line-17.png")}
      />
      <Text style={styles.time}>Time:</Text>
      <Image
        style={[styles.overlayChild3, styles.overlayChildLayout]}
        resizeMode="cover"
        source={require("../assets/line-18.png")}
      />
      <Pressable
        style={styles.pressable}
        onPress={() => navigation.navigate("Scheduler1")}
      >
        <Text style={[styles.text35, styles.next1Typo]}>+</Text>
      </Pressable>
      <Pressable
        style={styles.next}
        onPress={() => navigation.navigate("SetADate")}
      >
        <Text style={[styles.next1, styles.next1Typo]}>Next</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  mTypo: {
    height: 66,
    top: 167,
    opacity: 0.35,
    letterSpacing: 24,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.karmaRegular,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  wLayout: {
    width: 34,
    left: 127,
  },
  textLayout1: {
    width: 35,
    left: 176,
  },
  textPosition10: {
    left: 226,
    width: 33,
  },
  textPosition9: {
    left: 275,
    width: 33,
  },
  textPosition8: {
    left: 324,
    width: 33,
  },
  textLayout: {
    height: 32,
    color: Color.black,
    fontSize: FontSize.h3_size,
  },
  textTypo3: {
    top: 300,
    height: 32,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.karmaRegular,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  textPosition6: {
    left: 31,
    width: 33,
  },
  textPosition5: {
    left: 80,
    width: 33,
  },
  textPosition4: {
    left: 128,
    width: 34,
  },
  textPosition3: {
    left: 177,
    width: 35,
  },
  textPosition2: {
    left: 227,
    width: 33,
  },
  textPosition1: {
    left: 276,
    width: 33,
  },
  textPosition: {
    left: 325,
    width: 33,
  },
  textTypo1: {
    top: 434,
    height: 32,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.karmaRegular,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  textTypo: {
    top: 501,
    height: 32,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.karmaRegular,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  overlayLayout: {
    width: 367,
    borderRadius: Border.br_xl,
    left: 6,
    height: 66,
    position: "absolute",
  },
  amTypo: {
    height: 27,
    width: 95,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    left: 23,
    textAlign: "center",
    color: Color.black,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  newEventTypo: {
    height: 28,
    textAlign: "center",
    color: Color.black,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  lineViewLayout: {
    height: 1,
    width: 368,
    borderTopWidth: 1,
    borderColor: "#000",
    borderStyle: "solid",
    left: 6,
    position: "absolute",
  },
  insertTypo: {
    height: 21,
    width: 169,
    color: Color.white,
    fontSize: FontSize.size_xl,
    left: 19,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    textAlign: "center",
    position: "absolute",
  },
  pm1pmLayout: {
    height: 14,
    width: 106,
    left: 257,
    color: Color.white,
    fontSize: FontSize.size_xl,
  },
  pm1pmTypo: {
    top: 733,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    textAlign: "center",
    position: "absolute",
  },
  overlayIconPosition: {
    top: 357,
    left: 0,
    position: "absolute",
  },
  dateTypo: {
    height: 34,
    width: 100,
    opacity: 0.35,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.karmaRegular,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  overlayChildLayout: {
    height: 3,
    width: 335,
    opacity: 0.35,
    position: "absolute",
  },
  next1Typo: {
    color: Color.black,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
  },
  setADate: {
    top: 97,
    left: 114,
    width: 161,
    height: 35,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.karmaRegular,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  m: {
    opacity: 0.35,
    width: 33,
    left: 30,
  },
  t: {
    left: 79,
    opacity: 0.35,
    width: 33,
  },
  w: {
    opacity: 0.35,
    height: 66,
    top: 167,
    letterSpacing: 24,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.karmaRegular,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  t1: {
    opacity: 0.35,
    height: 66,
    top: 167,
    letterSpacing: 24,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.karmaRegular,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  f: {
    opacity: 0.35,
    height: 66,
    top: 167,
    letterSpacing: 24,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.karmaRegular,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  s: {
    opacity: 0.35,
    height: 66,
    top: 167,
    letterSpacing: 24,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.karmaRegular,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  s1: {
    opacity: 0.35,
    height: 66,
    top: 167,
    letterSpacing: 24,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.karmaRegular,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  text: {
    top: 233,
    height: 32,
    letterSpacing: 24,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
    position: "absolute",
    width: 33,
    left: 30,
  },
  text1: {
    top: 233,
    height: 32,
    letterSpacing: 24,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
    position: "absolute",
    left: 79,
    width: 33,
  },
  text2: {
    top: 233,
    height: 32,
    letterSpacing: 24,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
    position: "absolute",
    width: 34,
    left: 127,
  },
  text3: {
    top: 233,
    height: 32,
    letterSpacing: 24,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
    position: "absolute",
    width: 35,
    left: 176,
  },
  text4: {
    top: 233,
    height: 32,
    letterSpacing: 24,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
    position: "absolute",
    left: 226,
    width: 33,
  },
  text5: {
    top: 233,
    height: 32,
    letterSpacing: 24,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
    position: "absolute",
    left: 275,
    width: 33,
  },
  text6: {
    top: 233,
    height: 32,
    letterSpacing: 24,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
    position: "absolute",
    left: 324,
    width: 33,
  },
  text7: {
    width: 33,
    letterSpacing: 24,
    top: 300,
    left: 30,
  },
  text8: {
    left: 79,
    width: 33,
    letterSpacing: 24,
    top: 300,
  },
  text9: {
    width: 43,
    left: 127,
    top: 300,
  },
  text10: {
    width: 35,
    left: 176,
  },
  text11: {
    left: 226,
    width: 33,
  },
  text12: {
    left: 275,
    width: 33,
  },
  text13: {
    left: 324,
    width: 33,
  },
  text14: {
    top: 367,
    height: 32,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.karmaRegular,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  text15: {
    top: 367,
    height: 32,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.karmaRegular,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  text16: {
    top: 367,
    height: 32,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.karmaRegular,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  text17: {
    top: 367,
    height: 32,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.karmaRegular,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  text18: {
    top: 367,
    height: 32,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.karmaRegular,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  text19: {
    top: 367,
    height: 32,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.karmaRegular,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  text20: {
    top: 367,
    height: 32,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.karmaRegular,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  text21: {
    left: 31,
    width: 33,
  },
  text22: {
    left: 80,
    width: 33,
  },
  text23: {
    left: 128,
    width: 34,
  },
  text24: {
    left: 177,
    width: 35,
  },
  text25: {
    left: 227,
    width: 33,
  },
  text26: {
    left: 276,
    width: 33,
  },
  text27: {
    left: 325,
    width: 33,
  },
  text28: {
    left: 31,
    width: 33,
  },
  text29: {
    left: 80,
    width: 33,
  },
  text30: {
    left: 128,
    width: 34,
  },
  text31: {
    left: 177,
    width: 35,
    opacity: 0.35,
  },
  text32: {
    left: 227,
    width: 33,
    opacity: 0.35,
  },
  text33: {
    left: 276,
    width: 33,
    opacity: 0.35,
  },
  text34: {
    left: 325,
    width: 33,
    opacity: 0.35,
  },
  overlayChild: {
    backgroundColor: Color.mediumpurple,
    top: 614,
  },
  am: {
    top: 575,
  },
  powerWasher: {
    left: 15,
    width: 183,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    top: 614,
  },
  overlayItem: {
    top: 647,
  },
  insertNoteHere: {
    top: 652,
  },
  am11am: {
    top: 618,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    textAlign: "center",
    position: "absolute",
  },
  overlayInner: {
    top: 729,
    backgroundColor: Color.palevioletred,
  },
  pm: {
    top: 690,
  },
  windowCleaner: {
    left: 7,
    width: 224,
    height: 32,
    color: Color.black,
    fontSize: FontSize.h3_size,
  },
  lineView: {
    top: 762,
  },
  insertNoteHere1: {
    top: 767,
  },
  pm1pm: {
    height: 14,
    width: 106,
    left: 257,
    color: Color.white,
    fontSize: FontSize.size_xl,
  },
  overlayIcon: {
    top: 0,
    opacity: 0.2,
    width: 390,
    left: 0,
    position: "absolute",
    height: 844,
  },
  overlayIcon1: {
    height: 487,
    width: 390,
  },
  overlayIcon2: {
    borderRadius: 11,
    width: 392,
    height: 489,
  },
  newEvent: {
    top: 376,
    width: 238,
    left: 79,
    fontFamily: FontFamily.karmaRegular,
  },
  date: {
    top: 457,
    left: -1,
  },
  lineIcon: {
    top: 504,
    left: 22,
    height: 3,
    width: 335,
  },
  title: {
    top: 550,
    left: -2,
  },
  overlayChild1: {
    top: 597,
    height: 3,
    width: 335,
    left: 23,
  },
  instructions: {
    top: 648,
    left: 11,
    width: 138,
    opacity: 0.35,
    textAlign: "center",
    fontFamily: FontFamily.karmaRegular,
    position: "absolute",
  },
  overlayChild2: {
    top: 695,
    left: 22,
    height: 3,
    width: 335,
  },
  time: {
    top: 736,
    left: 1,
    width: 100,
    opacity: 0.35,
    height: 35,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.karmaRegular,
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  overlayChild3: {
    top: 785,
    height: 3,
    width: 335,
    left: 23,
  },
  text35: {
    fontSize: 36,
    width: 26,
    height: 30,
    transform: [
      {
        rotate: "46deg",
      },
    ],
    textAlign: "center",
  },
  pressable: {
    left: 49,
    top: 371,
    position: "absolute",
  },
  next1: {
    textAlign: "center",
    fontSize: FontSize.h3_size,
    color: Color.black,
  },
  next: {
    left: 310,
    top: 391,
    position: "absolute",
  },
  overlay: {
    backgroundColor: Color.lavenderblush,
    flex: 1,
    width: "100%",
    overflow: "hidden",
    height: 844,
  },
});

export default Overlay;
