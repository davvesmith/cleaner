import * as React from "react";
import { StyleSheet, View, Pressable, Text, Image } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const ServiceIntro = () => {
  const navigation = useNavigation();

  return (
    <Pressable
      style={[styles.serviceIntro, styles.iphone141Layout1]}
      onPress={() => navigation.navigate("CommercialServices")}
    >
      <View style={[styles.iphone141, styles.iphone141Position]}>
        <Pressable
          style={[styles.iphone141Child, styles.iphone141Layout]}
          onPress={() => navigation.navigate("CarServices")}
        />
        <Pressable
          style={[styles.iphone141Item, styles.iphone141Layout]}
          onPress={() => navigation.navigate("CommercialServices")}
        />
        <Pressable
          style={[styles.iphone141Inner, styles.iphone141Layout]}
          onPress={() => navigation.navigate("ResidentialServices")}
        />
        <Text style={[styles.commercial, styles.commercialTypo]}>
          Commercial
        </Text>
        <Text style={[styles.residential, styles.commercialTypo]}>
          Residential
        </Text>
        <Text style={[styles.welcomePickYour, styles.serviceTypo]}>{`Welcome!

Pick your service and we can get started.`}</Text>
        <Text style={styles.automotive}>Automotive</Text>
      </View>
      <Text style={[styles.service, styles.serviceTypo]}>Service</Text>
      <View style={[styles.serviceIntroChild, styles.serviceChildPosition]} />
      <Image
        style={[styles.serviceIntroItem, styles.iphone141Position]}
        resizeMode="cover"
        source={require("../assets/rectangle-11.png")}
      />
      <View style={[styles.serviceIntroInner, styles.serviceLayout]} />
      <Pressable
        style={styles.wrapper}
        onPress={() => navigation.navigate("Favorites")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/star-2.png")}
        />
      </Pressable>
      <View style={[styles.lineView, styles.serviceLayout]} />
      <Image
        style={[styles.ellipseIcon, styles.ellipseIconLayout]}
        resizeMode="cover"
        source={require("../assets/ellipse-2.png")}
      />
      <Image
        style={styles.lineIcon}
        resizeMode="cover"
        source={require("../assets/line-5.png")}
      />
      <View style={[styles.serviceIntroChild1, styles.serviceLayout]} />
      <View style={[styles.serviceIntroChild2, styles.serviceChildPosition]} />
      <View style={[styles.rectangleView, styles.ellipseIconLayout]} />
      <Image
        style={styles.polygonIcon}
        resizeMode="cover"
        source={require("../assets/polygon-1.png")}
      />
      <Image
        style={styles.serviceIntroChild3}
        resizeMode="cover"
        source={require("../assets/ellipse-1.png")}
      />
      <Text style={[styles.profile, styles.serviceTypo]}>Profile</Text>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  iphone141Layout1: {
    overflow: "hidden",
    height: 844,
    backgroundColor: Color.lavenderblush,
  },
  iphone141Position: {
    left: 0,
    top: 0,
    width: 390,
    position: "absolute",
  },
  iphone141Layout: {
    height: 62,
    width: 321,
    borderWidth: 3,
    backgroundColor: Color.plum,
    borderRadius: Border.br_3xs,
    left: 35,
    borderColor: "#000",
    borderStyle: "solid",
    position: "absolute",
  },
  commercialTypo: {
    width: 283,
    left: 50,
    height: 39,
    textAlign: "center",
    color: Color.white,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  serviceTypo: {
    color: Color.black,
    textAlign: "center",
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    position: "absolute",
  },
  serviceChildPosition: {
    top: 759,
    left: 0,
    position: "absolute",
  },
  serviceLayout: {
    height: 86,
    width: 1,
    borderRightWidth: 1,
    top: 759,
    borderColor: "#000",
    borderStyle: "solid",
    position: "absolute",
  },
  ellipseIconLayout: {
    width: 30,
    position: "absolute",
  },
  iphone141Child: {
    top: 360,
  },
  iphone141Item: {
    top: 451,
  },
  iphone141Inner: {
    top: 535,
  },
  commercial: {
    top: 467,
    height: 39,
  },
  residential: {
    top: 552,
    height: 39,
  },
  welcomePickYour: {
    top: 164,
    fontSize: FontSize.size_xl,
    width: 217,
    height: 93,
    left: 83,
  },
  automotive: {
    top: 379,
    left: 121,
    width: 142,
    height: 34,
    textAlign: "center",
    color: Color.white,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    fontSize: FontSize.h3_size,
    position: "absolute",
  },
  iphone141: {
    width: 390,
    overflow: "hidden",
    height: 844,
    backgroundColor: Color.lavenderblush,
  },
  service: {
    top: 18,
    left: 30,
    fontSize: FontSize.size_29xl,
    width: 329,
    height: 39,
  },
  serviceIntroChild: {
    backgroundColor: Color.darkslateblue,
    height: 85,
    width: 390,
  },
  serviceIntroItem: {
    height: 103,
    opacity: 0.2,
    width: 390,
  },
  serviceIntroInner: {
    left: 83,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  wrapper: {
    left: 207,
    top: 773,
    width: 74,
    height: 58,
    position: "absolute",
  },
  lineView: {
    left: 294,
  },
  ellipseIcon: {
    top: 788,
    left: 117,
    height: 27,
  },
  lineIcon: {
    top: 811,
    left: 143,
    width: 15,
    height: 13,
    position: "absolute",
  },
  serviceIntroChild1: {
    left: 189,
  },
  serviceIntroChild2: {
    borderTopWidth: 1,
    width: 391,
    height: 1,
    borderColor: "#000",
    borderStyle: "solid",
  },
  rectangleView: {
    top: 798,
    left: 25,
    backgroundColor: Color.white,
    borderWidth: 2,
    height: 26,
    borderColor: "#000",
    borderStyle: "solid",
  },
  polygonIcon: {
    top: 780,
    left: 18,
    width: 53,
    height: 29,
    position: "absolute",
  },
  serviceIntroChild3: {
    top: 774,
    left: 315,
    width: 59,
    height: 56,
    position: "absolute",
  },
  profile: {
    top: 791,
    left: 304,
    fontSize: FontSize.size_base,
    width: 81,
    height: 22,
  },
  serviceIntro: {
    flex: 1,
    width: "100%",
  },
});

export default ServiceIntro;
