import * as React from "react";
import { Text, StyleSheet, View, Image, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const SetADate = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.setADate}>
      <Text style={[styles.letsScheduleThe, styles.scheduleFlexBox]}>
        Lets schedule the day and time you will need your service!
      </Text>
      <View style={[styles.setADateChild, styles.setPosition]} />
      <Image
        style={[styles.setADateItem, styles.setPosition]}
        resizeMode="cover"
        source={require("../assets/rectangle-11.png")}
      />
      <View style={[styles.setADateInner, styles.setLayout]} />
      <Pressable
        style={styles.wrapper}
        onPress={() => navigation.navigate("Favorites")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/star-1.png")}
        />
      </Pressable>
      <View style={[styles.lineView, styles.setLayout]} />
      <Image
        style={styles.ellipseIcon}
        resizeMode="cover"
        source={require("../assets/ellipse-2.png")}
      />
      <View style={[styles.setADateChild1, styles.setLayout]} />
      <View style={styles.setADateChild2} />
      <Image
        style={styles.polygonIcon}
        resizeMode="cover"
        source={require("../assets/polygon-1.png")}
      />
      <Image
        style={styles.setADateChild3}
        resizeMode="cover"
        source={require("../assets/ellipse-1.png")}
      />
      <Image
        style={styles.setADateChild4}
        resizeMode="cover"
        source={require("../assets/ellipse-4.png")}
      />
      <Pressable
        style={styles.rectanglePressable}
        onPress={() => navigation.navigate("ServiceIntro")}
      />
      <View style={styles.rectangleView} />
      <Text style={[styles.schedule, styles.scheduleFlexBox]}>Schedule</Text>
      <Pressable
        style={styles.confirm}
        onPress={() => navigation.navigate("IPhone145")}
      >
        <Text style={[styles.confirm1, styles.dateTypo]}>Confirm</Text>
      </Pressable>
      <Image
        style={styles.lineIcon}
        resizeMode="cover"
        source={require("../assets/line-5.png")}
      />
      <Text style={[styles.date, styles.dateTypo]}>Date</Text>
      <Text style={[styles.time, styles.timeLayout]}>Time</Text>
      <View style={[styles.setADateChild5, styles.setChildLayout1]} />
      <View style={[styles.setADateChild6, styles.setChildLayout1]} />
      <Image
        style={[styles.starIcon, styles.setChildPosition]}
        resizeMode="cover"
        source={require("../assets/star-27.png")}
      />
      <Image
        style={[styles.setADateChild7, styles.setChildPosition]}
        resizeMode="cover"
        source={require("../assets/star-28.png")}
      />
      <Image
        style={[styles.setADateChild8, styles.setChildPosition]}
        resizeMode="cover"
        source={require("../assets/star-27.png")}
      />
      <Image
        style={[styles.setADateChild9, styles.setChildPosition]}
        resizeMode="cover"
        source={require("../assets/star-27.png")}
      />
      <Image
        style={[styles.setADateChild10, styles.setChildPosition]}
        resizeMode="cover"
        source={require("../assets/star-27.png")}
      />
      <Text style={[styles.bigClean, styles.scheduleFlexBox]}>Big Clean</Text>
      <Image
        style={[styles.baldGuy1, styles.timeLayout]}
        resizeMode="cover"
        source={require("../assets/bald-guy-21.png")}
      />
      <Text style={[styles.profile, styles.scheduleFlexBox]}>Profile</Text>
      <Pressable
        style={styles.back}
        onPress={() => navigation.navigate("Overlay")}
      >
        <Text style={[styles.back1, styles.scheduleFlexBox]}>Back</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  scheduleFlexBox: {
    textAlign: "center",
    color: Color.black,
  },
  setPosition: {
    width: 390,
    left: 0,
    position: "absolute",
  },
  setLayout: {
    height: 86,
    width: 1,
    borderRightWidth: 1,
    borderColor: "#000",
    borderStyle: "solid",
    top: 759,
    position: "absolute",
  },
  dateTypo: {
    fontSize: FontSize.size_21xl,
    textAlign: "center",
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
  },
  timeLayout: {
    width: 97,
    position: "absolute",
  },
  setChildLayout1: {
    height: 41,
    width: 181,
    left: 156,
    borderWidth: 1,
    backgroundColor: Color.white,
    borderColor: "#000",
    borderStyle: "solid",
    position: "absolute",
  },
  setChildPosition: {
    height: 36,
    top: 517,
    position: "absolute",
  },
  letsScheduleThe: {
    top: 185,
    left: 61,
    width: 256,
    height: 101,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    textAlign: "center",
    position: "absolute",
    fontSize: FontSize.size_base,
  },
  setADateChild: {
    backgroundColor: Color.darkslateblue,
    height: 85,
    top: 759,
    left: 0,
  },
  setADateItem: {
    top: 0,
    height: 103,
    opacity: 0.2,
  },
  setADateInner: {
    left: 83,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  wrapper: {
    left: 207,
    top: 773,
    width: 63,
    height: 57,
    position: "absolute",
  },
  lineView: {
    left: 294,
  },
  ellipseIcon: {
    top: 788,
    left: 117,
    width: 30,
    height: 27,
    position: "absolute",
  },
  setADateChild1: {
    left: 189,
  },
  setADateChild2: {
    borderTopWidth: 1,
    width: 391,
    height: 1,
    borderColor: "#000",
    borderStyle: "solid",
    left: 0,
    top: 759,
    position: "absolute",
  },
  polygonIcon: {
    top: 780,
    left: 18,
    width: 53,
    height: 29,
    position: "absolute",
  },
  setADateChild3: {
    top: 774,
    left: 315,
    width: 59,
    height: 56,
    position: "absolute",
  },
  setADateChild4: {
    top: 473,
    width: 75,
    height: 71,
    left: 26,
    position: "absolute",
  },
  rectanglePressable: {
    top: 800,
    borderWidth: 2,
    width: 28,
    height: 18,
    backgroundColor: Color.white,
    left: 26,
    borderColor: "#000",
    borderStyle: "solid",
    position: "absolute",
  },
  rectangleView: {
    top: 616,
    left: 52,
    borderRadius: Border.br_3xs,
    backgroundColor: Color.steelblue,
    width: 290,
    height: 76,
    borderWidth: 1,
    borderColor: "#000",
    borderStyle: "solid",
    position: "absolute",
  },
  schedule: {
    top: 18,
    left: 16,
    fontSize: FontSize.size_29xl,
    width: 346,
    height: 66,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    textAlign: "center",
    position: "absolute",
  },
  confirm1: {
    color: Color.white,
    width: 258,
    height: 52,
  },
  confirm: {
    left: 66,
    top: 628,
    position: "absolute",
  },
  lineIcon: {
    top: 809,
    left: 143,
    width: 15,
    height: 13,
    position: "absolute",
  },
  date: {
    top: 276,
    width: 109,
    height: 20,
    left: 22,
    color: Color.black,
    fontSize: FontSize.size_21xl,
    position: "absolute",
  },
  time: {
    top: 359,
    left: 35,
    height: 47,
    fontSize: FontSize.size_21xl,
    textAlign: "center",
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    color: Color.black,
  },
  setADateChild5: {
    top: 281,
  },
  setADateChild6: {
    top: 366,
  },
  starIcon: {
    left: 142,
    width: 39,
    height: 36,
    top: 517,
  },
  setADateChild7: {
    left: 185,
    width: 41,
    height: 36,
    top: 517,
  },
  setADateChild8: {
    left: 227,
    width: 39,
    height: 36,
    top: 517,
  },
  setADateChild9: {
    left: 266,
    width: 39,
    height: 36,
    top: 517,
  },
  setADateChild10: {
    left: 307,
    width: 39,
    height: 36,
    top: 517,
  },
  bigClean: {
    top: 463,
    left: 108,
    fontSize: FontSize.size_13xl,
    fontFamily: FontFamily.firaSansRegular,
    width: 199,
    height: 46,
    position: "absolute",
  },
  baldGuy1: {
    top: 469,
    height: 84,
    left: 22,
  },
  profile: {
    top: 791,
    left: 304,
    width: 81,
    height: 22,
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    textAlign: "center",
    position: "absolute",
    fontSize: FontSize.size_base,
  },
  back1: {
    fontSize: FontSize.h3_size,
    fontFamily: FontFamily.karmaRegular,
    width: 98,
    height: 28,
  },
  back: {
    left: -9,
    top: 157,
    position: "absolute",
  },
  setADate: {
    backgroundColor: Color.lavenderblush,
    flex: 1,
    height: 844,
    overflow: "hidden",
    width: "100%",
  },
});

export default SetADate;
