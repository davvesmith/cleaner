import * as React from "react";
import { Text, StyleSheet, View, Image, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const IPhone145 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.iphone145}>
      <Text style={[styles.greatChoiceLeave, styles.back1Clr]}>{`Great Choice!

Leave a review on this companies work after the work is done.`}</Text>
      <View style={[styles.iphone145Child, styles.iphone145Position]} />
      <Image
        style={[styles.iphone145Item, styles.iphone145Position]}
        resizeMode="cover"
        source={require("../assets/rectangle-11.png")}
      />
      <View style={[styles.iphone145Inner, styles.iphone145Layout]} />
      <Pressable
        style={styles.wrapper}
        onPress={() => navigation.navigate("Favorites")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/star-1.png")}
        />
      </Pressable>
      <View style={[styles.lineView, styles.iphone145Layout]} />
      <Image
        style={styles.ellipseIcon}
        resizeMode="cover"
        source={require("../assets/ellipse-2.png")}
      />
      <View style={[styles.iphone145Child1, styles.iphone145Layout]} />
      <View style={[styles.iphone145Child2, styles.rectangleBorder]} />
      <Image
        style={styles.polygonIcon}
        resizeMode="cover"
        source={require("../assets/polygon-1.png")}
      />
      <Image
        style={styles.iphone145Child3}
        resizeMode="cover"
        source={require("../assets/ellipse-1.png")}
      />
      <Pressable
        style={[styles.rectanglePressable, styles.rectangleBorder]}
        onPress={() => navigation.navigate("ServiceIntro")}
      />
      <View style={[styles.rectangleView, styles.rectangleBorder]} />
      <Text style={[styles.booking, styles.back1Clr]}>Booking</Text>
      <Pressable
        style={styles.goHome}
        onPress={() => navigation.navigate("HomePage")}
      >
        <Text style={[styles.goHome1, styles.bookingTypo]}>{`Go Home
`}</Text>
      </Pressable>
      <Image
        style={styles.lineIcon}
        resizeMode="cover"
        source={require("../assets/line-5.png")}
      />
      <Image
        style={styles.iphone145Child4}
        resizeMode="cover"
        source={require("../assets/ellipse-4.png")}
      />
      <Image
        style={[styles.starIcon, styles.iphone145ChildPosition]}
        resizeMode="cover"
        source={require("../assets/star-27.png")}
      />
      <Image
        style={[styles.iphone145Child5, styles.iphone145ChildPosition]}
        resizeMode="cover"
        source={require("../assets/star-28.png")}
      />
      <Image
        style={[styles.iphone145Child6, styles.iphone145ChildPosition]}
        resizeMode="cover"
        source={require("../assets/star-27.png")}
      />
      <Image
        style={[styles.iphone145Child7, styles.iphone145ChildPosition]}
        resizeMode="cover"
        source={require("../assets/star-27.png")}
      />
      <Image
        style={[styles.iphone145Child8, styles.iphone145ChildPosition]}
        resizeMode="cover"
        source={require("../assets/star-27.png")}
      />
      <Text style={[styles.bigClean, styles.back1Clr]}>Big Clean</Text>
      <Image
        style={styles.baldGuy2}
        resizeMode="cover"
        source={require("../assets/bald-guy-21.png")}
      />
      <Text style={[styles.profile, styles.back1Clr]}>Profile</Text>
      <Pressable
        style={styles.back}
        onPress={() => navigation.navigate("SetADate")}
      >
        <Text style={[styles.back1, styles.back1Clr]}>Back</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  back1Clr: {
    color: Color.black,
    textAlign: "center",
  },
  iphone145Position: {
    width: 390,
    left: 0,
    position: "absolute",
  },
  iphone145Layout: {
    height: 86,
    width: 1,
    borderRightWidth: 1,
    borderColor: "#000",
    borderStyle: "solid",
    top: 759,
    position: "absolute",
  },
  rectangleBorder: {
    borderColor: "#000",
    borderStyle: "solid",
    position: "absolute",
  },
  bookingTypo: {
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
  },
  iphone145ChildPosition: {
    height: 36,
    top: 416,
    position: "absolute",
  },
  greatChoiceLeave: {
    top: 185,
    left: 61,
    width: 256,
    height: 101,
    textAlign: "center",
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_base,
    color: Color.black,
    position: "absolute",
  },
  iphone145Child: {
    backgroundColor: Color.darkslateblue,
    height: 85,
    top: 759,
    width: 390,
  },
  iphone145Item: {
    top: 0,
    height: 103,
    opacity: 0.2,
  },
  iphone145Inner: {
    left: 83,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  wrapper: {
    left: 207,
    top: 773,
    width: 63,
    height: 57,
    position: "absolute",
  },
  lineView: {
    left: 294,
  },
  ellipseIcon: {
    top: 788,
    left: 117,
    width: 30,
    height: 27,
    position: "absolute",
  },
  iphone145Child1: {
    left: 189,
  },
  iphone145Child2: {
    borderTopWidth: 1,
    width: 391,
    height: 1,
    left: 0,
    borderStyle: "solid",
    top: 759,
  },
  polygonIcon: {
    top: 780,
    left: 18,
    width: 53,
    height: 29,
    position: "absolute",
  },
  iphone145Child3: {
    top: 774,
    left: 315,
    width: 59,
    height: 56,
    position: "absolute",
  },
  rectanglePressable: {
    top: 800,
    left: 26,
    backgroundColor: Color.white,
    borderWidth: 2,
    width: 28,
    height: 18,
  },
  rectangleView: {
    top: 529,
    left: 52,
    borderRadius: Border.br_3xs,
    backgroundColor: Color.steelblue,
    borderWidth: 1,
    width: 290,
    height: 76,
  },
  booking: {
    top: 18,
    left: 16,
    fontSize: FontSize.size_29xl,
    width: 346,
    height: 66,
    textAlign: "center",
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    position: "absolute",
  },
  goHome1: {
    fontSize: FontSize.size_21xl,
    color: Color.white,
    width: 258,
    height: 52,
    textAlign: "center",
  },
  goHome: {
    left: 66,
    top: 541,
    position: "absolute",
  },
  lineIcon: {
    top: 809,
    left: 143,
    width: 15,
    height: 13,
    position: "absolute",
  },
  iphone145Child4: {
    top: 372,
    left: 47,
    width: 75,
    height: 71,
    position: "absolute",
  },
  starIcon: {
    left: 163,
    width: 39,
    height: 36,
    top: 416,
  },
  iphone145Child5: {
    left: 206,
    width: 41,
    height: 36,
    top: 416,
  },
  iphone145Child6: {
    left: 248,
    width: 39,
    height: 36,
    top: 416,
  },
  iphone145Child7: {
    left: 287,
    width: 39,
    height: 36,
    top: 416,
  },
  iphone145Child8: {
    left: 328,
    width: 39,
    height: 36,
    top: 416,
  },
  bigClean: {
    top: 362,
    left: 129,
    fontSize: FontSize.size_13xl,
    fontFamily: FontFamily.firaSansRegular,
    width: 199,
    height: 46,
    textAlign: "center",
    position: "absolute",
  },
  baldGuy2: {
    top: 368,
    left: 43,
    width: 97,
    height: 84,
    position: "absolute",
  },
  profile: {
    top: 791,
    left: 304,
    width: 81,
    height: 22,
    textAlign: "center",
    fontFamily: FontFamily.karmaSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_base,
    color: Color.black,
    position: "absolute",
  },
  back1: {
    fontSize: FontSize.h3_size,
    fontFamily: FontFamily.karmaRegular,
    width: 98,
    height: 28,
    textAlign: "center",
  },
  back: {
    left: -13,
    top: 162,
    position: "absolute",
  },
  iphone145: {
    backgroundColor: Color.lavenderblush,
    flex: 1,
    height: 844,
    overflow: "hidden",
    width: "100%",
  },
});

export default IPhone145;
