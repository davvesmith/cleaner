import * as React from "react";
import { Image, StyleSheet, Text, View, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const Homepage1 = () => {
  const navigation = useNavigation();

  return (
    <Pressable
      style={styles.homepage}
      onPress={() => navigation.navigate("Login")}
    >
      <Image
        style={styles.homepageChild}
        resizeMode="cover"
        source={require("../assets/ellipse-11.png")}
      />
      <Text style={styles.welcomeToSunny}>Welcome to Sunny Side Cleaners</Text>
      <View style={[styles.homepageItem, styles.homepageLayout]} />
      <Text style={[styles.signUp, styles.loginTypo]}>Sign Up</Text>
      <Pressable
        style={styles.homepageLayout}
        onPress={() => navigation.navigate("Login")}
      />
      <Text style={[styles.login, styles.loginTypo]}>Login</Text>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  homepageLayout: {
    height: 55,
    width: 309,
    borderWidth: 2,
    borderColor: "#000",
    borderStyle: "solid",
    backgroundColor: Color.plum,
    borderRadius: Border.br_3xs,
    marginTop: 5,
  },
  loginTypo: {
    width: 285,
    fontSize: FontSize.h3_size,
    marginTop: 5,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.karmaRegular,
  },
  homepageChild: {
    width: 317,
    height: 316,
  },
  welcomeToSunny: {
    fontSize: FontSize.size_xl,
    width: 311,
    height: 40,
    marginTop: 5,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.karmaRegular,
  },
  homepageItem: {
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
  },
  signUp: {
    height: 41,
  },
  login: {
    height: 37,
  },
  homepage: {
    backgroundColor: Color.lavenderblush,
    flex: 1,
    width: "100%",
    height: 849,
    overflow: "hidden",
    paddingHorizontal: 34,
    paddingVertical: 123,
    alignItems: "center",
  },
});

export default Homepage1;
