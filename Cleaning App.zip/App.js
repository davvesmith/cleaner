const Stack = createNativeStackNavigator();
import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";

import Favorites from "./screens/Favorites";
import HomePage from "./screens/HomePage";
import IPhone145 from "./screens/IPhone145";
import SetADate from "./screens/SetADate";
import ComapniesLists from "./screens/ComapniesLists";
import CarServices from "./screens/CarServices";
import ResidentialServices from "./screens/ResidentialServices";
import CommercialServices from "./screens/CommercialServices";
import ServiceIntro from "./screens/ServiceIntro";
import Services from "./screens/Services";
import Login from "./screens/Login";
import Overlay from "./screens/Overlay";
import Scheduler1 from "./screens/Scheduler1";
import Homepage1 from "./screens/Homepage1";

import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { View, Text, Pressable, TouchableOpacity } from "react-native";

const App = () => {
  const [hideSplashScreen, setHideSplashScreen] = React.useState(true);

  return (
    <>
      <NavigationContainer>
        {hideSplashScreen ? (
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen
              name="Favorites"
              component={Favorites}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="HomePage"
              component={HomePage}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone145"
              component={IPhone145}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SetADate"
              component={SetADate}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ComapniesLists"
              component={ComapniesLists}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CarServices"
              component={CarServices}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ResidentialServices"
              component={ResidentialServices}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CommercialServices"
              component={CommercialServices}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ServiceIntro"
              component={ServiceIntro}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Services"
              component={Services}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Login"
              component={Login}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Overlay"
              component={Overlay}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Scheduler1"
              component={Scheduler1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Homepage1"
              component={Homepage1}
              options={{ headerShown: false }}
            />
          </Stack.Navigator>
        ) : null}
      </NavigationContainer>
    </>
  );
};
export default App;
