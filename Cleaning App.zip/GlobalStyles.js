/* fonts */
export const FontFamily = {
  karmaRegular: "Karma-Regular",
  firaSansRegular: "FiraSans-Regular",
  karmaSemiBold: "Karma-SemiBold",
  h3: "Inter-Bold",
};
/* font sizes */
export const FontSize = {
  h3_size: 24,
  size_base: 16,
  size_29xl: 48,
  size_13xl: 32,
  size_21xl: 40,
  size_xl: 20,
};
/* Colors */
export const Color = {
  lavenderblush: "#fff3f3",
  black: "#000",
  white: "#fff",
  darkslateblue: "#3f4293",
  gainsboro: "#d9d9d9",
  steelblue: "#4e90cc",
  plum: "#99699d",
  palevioletred: "#e080a3",
  mediumpurple: "#b080e0",
};
/* border radiuses */
export const Border = {
  br_3xs: 10,
  br_xl: 20,
};
